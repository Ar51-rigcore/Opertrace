<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Share the OPERTRACE domain catalog between the platform page and public stateless AI advisor so recommendations use the same product source.
- Keep AI inference (solution advisor and fleet-flow planner) inside server functions using the typed AI Gateway SDK with strict JSON schemas; validate returned domain names against the shared catalog before displaying.
- Fleet planner stream collection stops at terminal response events so completed results do not depend on the transport closing; keep a regression test for that boundary.
- Lead forms insert through a public server function using the publishable client into insert-only tables; visitors can never read submissions back.
- Define both themes and semantic contrast pairs in global CSS, with automated token and rendered-component checks; reserve raw brand accent for fills and use readable brand text separately.
- Bootstrap the theme before first paint with guarded storage access, and keep theme switching usable when browser storage is blocked.
- Use the shared Accordion for footer disclosure navigation so browser-native restored disclosure state cannot diverge during hydration.
- Route files own leaf metadata; generated route types are updated by the router plugin, never manually.
- Render the shared brand logo from paired transparent light/dark assets and derive the favicon from the same logo, keeping theme switching independent of image processing.
- Home uses the Horizon opening, Platform keeps the industrial opening, and both reuse the fleet demonstration; keep illustrative fleet state separate from actual telemetry and AI recommendations.
- Keep the homepage mine-to-port explanation in its own image-led editorial component, explicitly marked illustrative, so explanatory stages never imply live telemetry or verified customer outcomes.
- Corporate and consultation pages use the shared PageIntro editorial opening and global spacing scale to keep navigation, imagery and typography cohesive.
- Keep service-specific image assignments and descriptive illustration labels in the shared page-imagery module; pass them explicitly to PageIntro so unrelated pages never inherit a generic photo.
- Repeated informational features use unframed editorial layouts; reserve framed surfaces and visible borders for interactive tools and controls to maintain clear reading hierarchy.
- The site header is fixed and floats transparently only over routes that open with the shared industrial photo; other routes get a header-height spacer from the header itself, so new photo-opening pages must be registered there.
- Brand fonts are self-hosted through bundled font packages imported at the top of the global stylesheet, so typography never depends on a third-party font host loading on mobile networks.
- Home and Platform openings fill the first phone screen; the Home opening motion is a decorative, motion-safe layer that never represents live telemetry.
