# OPERTRACE Corporate Website — Task List

## Context
Refactor landing page into full corporate website for PT Cakrakarsa Aditama Nusantara.
Flagship product renamed OPERION → **OPERTRACE**. Copy source: user's Master Website
Copywriting draft 2026 (uploaded). Design system: dark minimal + lime accent, Inter,
StoryBrand structure (already in src/styles.css + src/hooks/use-reveal.tsx).

## Current visual completion
- [ ] Rebuild Home, Platform, About, Technology, Industries, Contact, Demo and Fleet Guide with one Horizon Nusantara system; remove obsolete layouts and visible numbering
- [ ] Verify rebuilt pages and unclipped menus in both themes at phone and desktop sizes
- [x] Apply selected Nusantara headline and add an illustrative mine-to-port operational flow; verify both themes and screen sizes
- [ ] Apply approved Horizon Nusantara opening and cohesive unframed editorial layouts to all pages
- [ ] Install differentiated service imagery with Indonesian people; keep generated people separate from real staff profiles
- [ ] Validate all 13 pages on mobile/desktop in both themes, including clipping, images, navigation and fleet interaction
- [ ] Generate Platform video (blocked: video generation requires approximately 4.87 additional credits)

## Tasks
- [ ] Debug theme switching, footer hydration, and validate all pages in both themes
- [x] Repair and verify fleet planner results with real input
- [x] Verify demo submission reads back in Cloud and remove only the test row
- [ ] Enable demo notification to demo@opertrace.co.id (blocked: owned sender domain not verified)
- [x] Add profile photo spaces while preserving director/team order
- [ ] Add official Contact Us details (blocked: official address and phone not supplied)
- [ ] Replace old logo and separate brand text with the latest uploaded complete logo and favicon
- [x] Unify all page visuals, navigation, spacing and comfortable scrolling on desktop/mobile (floating header, scroll progress, calmer hero and footer)
- [x] Verify all content pages in both themes and mobile navigation
- [x] Install uploaded background-free logo for both themes and favicon
- [x] Present three distinct premium 2031-style visual mockups before redesign
- [x] Apply approved Industrial Lens visual redesign with interactive fleet demonstration
- [x] Add grounded OPERTRACE AI recommendations for prospective partners
- [x] AI fleet-flow planner for prospective fleet managers (AI Gateway)
- [x] Demo request form (name, email, fleet needs) stored in Cloud
- [x] Team in navigation + home team teaser
- [x] Mobile polish: fleet demo, navigation sheet, sticky CTA, full-width buttons
- [x] Restore /login, /contact, /legal and verify route links
- [x] Apply orange light/dark themes and automated contrast checks
- [x] Store badges replaced with user's App Store / Google Play images, horizontal layout
- [x] App section lists real OPERTRACE app features (Armada, Operasional, Passport, Digital)
- [ ] Verify AI flow, both themes and mobile layout
- [x] Shared site primitives (Container, Reveal, SectionHeading, Buttons, FeatureCard)
- [x] Sticky glassmorphism Header (logo left, links center, action right, mobile menu)
- [x] Multi-column semantic Footer (Company / Solutions / OPERTRACE / Industries / Connect / Legal)
- [x] `/` Home — StoryBrand 5 sections (Hero+mockup, Stakes, Guide/Solutions, Plan, Final CTA)
- [x] `/platform` — OPERTRACE product page: 24 domains, SEE/UNDERSTAND/ACT, beneficiaries
- [x] `/about` — About Us (Who We Are, What We Do, Approach)
- [x] `/vision` — Vision, Mission & Core Values (7 values)
- [x] `/technology` — Technology, Innovation & Trust (4 foundations, measurement pipeline, AI, security)
- [x] `/industries` — 6 sectors with solution lists + partnership CTA
- [x] `/team` — Leadership roles, professional teams, culture, careers CTA
- [x] `/contact` — 5 inquiry categories + business inquiry form (client-side success state)
- [x] `/login` — polished Sign In / Create Account gateway (client-side; no backend yet)
- [x] `/legal` — Privacy, Terms, Cookies, Corporate Information (one route)
- [x] Update __root title + verify all routes via Playwright, build log clean

## Open items (need user data)
- Director names/photos (Team page shows roles only — naskah forbids inventing names)
- Official address / email / phone / NIB (contact page uses form + placeholders-free copy)
- Real authentication backend (Lovable Cloud) for /login and contact form submission
