"""Audit every theme token and rendered text component against the live app.

Run after starting the site: python3 scripts/audit-contrast.py
Requires Playwright, Chromium, and installed axe-core. Sunlight testing still
requires physical devices; screenshots and ratios cannot simulate glare.
"""
import asyncio
import math
import re
from pathlib import Path
from playwright.async_api import async_playwright

ROOT = Path(__file__).resolve().parents[1]
ROUTES = ['/', '/platform', '/about', '/vision', '/technology', '/industries', '/team', '/login', '/contact', '/legal', '/demo', '/fleet-guide', '/fleet-planner']

def luminance(value):
    nums = [float(x) for x in re.findall(r'[-+]?\d*\.?\d+', value)]
    if value.startswith('oklch'):
        light, chroma, hue = nums[:3]
        a, b = chroma * math.cos(math.radians(hue)), chroma * math.sin(math.radians(hue))
        l = (light + .3963377774*a + .2158037573*b)**3
        m = (light - .1055613458*a - .0638541728*b)**3
        s = (light - .0894841775*a - 1.291485548*b)**3
        rgb = [4.0767416621*l-3.3077115913*m+.2309699292*s, -1.2684380046*l+2.6097574011*m-.3413193965*s, -.0041960863*l-.7034186147*m+1.707614701*s]
    else:
        rgb = [n/255 for n in nums[:3]]
        rgb = [c/12.92 if c <= .04045 else ((c+.055)/1.055)**2.4 for c in rgb]
    return sum(max(0, min(1, c))*w for c, w in zip(rgb, [.2126,.7152,.0722]))

def ratio(fg, bg):
    a, b = sorted([luminance(fg), luminance(bg)])
    return (b+.05)/(a+.05)

async def main():
    failures = []
    css = (ROOT/'src/styles.css').read_text()
    # Every role with a foreground token is explicitly paired; boundaries use 3:1.
    pairs = [('foreground','background',7), ('muted-foreground','muted',4.5), ('brand-text','background',4.5), ('critical-fg','critical-bg',7), ('border','background',3), ('input','card',3), ('ring','background',3)]
    pairs += [(f'{role}-foreground',role,4.5) for role in ['card','popover','primary','secondary','accent','destructive']]
    pairs += [(f'status-{status}',f'status-{status}-bg',4.5) for status in ['success','warning','info','danger']]
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        for width in [1280, 411]:
            context = await browser.new_context(viewport={'width':width,'height':1800 if width == 1280 else 719})
            page = await context.new_page()
            for theme in ['light','dark']:
                selector = ':root' if theme == 'light' else '.dark'
                block = css.split(selector+' {',1)[1].split('}',1)[0]
                tokens = dict(re.findall(r'--([a-z-]+):\s*(oklch\([^;]+\));',block))
                for fg,bg,minimum in pairs:
                    measured = ratio(tokens[fg],tokens[bg])
                    if measured + .001 < minimum: failures.append(f'{theme} {fg}/{bg}: {measured:.2f} < {minimum}')
                for route in ROUTES:
                    await page.goto('http://localhost:8080'+route, wait_until='networkidle')
                    await page.evaluate('(theme) => {localStorage.setItem("opertrace-theme",theme); document.documentElement.classList.toggle("dark",theme === "dark")}', theme)
                    await page.evaluate('''async () => { for (let y=0; y<document.body.scrollHeight; y+=600) {window.scrollTo(0,y); await new Promise(r=>setTimeout(r,60));} window.scrollTo(0,0);}''')
                    await page.wait_for_timeout(900)
                    await page.add_script_tag(path=str(ROOT/'node_modules/axe-core/axe.min.js'))
                    audit = await page.evaluate('''async () => {const r=await axe.run(document,{runOnly:{type:'rule',values:['color-contrast']}});return r.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>({target:n.target,summary:n.failureSummary}))}));}''')
                    if audit: failures.append(f'{width}px {theme} {route}: {audit}')
                    overflow = await page.evaluate('document.documentElement.scrollWidth > innerWidth')
                    if overflow: failures.append(f'{width}px {theme} {route}: horizontal overflow')
                    print(f'Checked {width}px {theme} {route}')
            await context.close()
        await browser.close()
    if failures:
        print('\n'.join(failures))
        raise SystemExit(1)
    print('PASS: all token pairs and rendered route components in both themes.')

asyncio.run(main())