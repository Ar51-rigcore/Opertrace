import { Download, LogIn, Smartphone } from 'lucide-react';
import { Container, Reveal } from './ui';
import badgeGooglePlay from '@/assets/badge-google-play.jpg.asset.json';
import badgeAppStore from '@/assets/badge-app-store.jpg.asset.json';

const STEPS = [
  { icon: Download, title: 'Unduh aplikasi', body: 'Cari "OPERTRACE" di App Store (iPhone/iPad) atau Google Play (Android).' },
  { icon: LogIn, title: 'Masuk dengan akun perusahaan', body: 'Gunakan akun yang dibuat admin armada Anda saat aktivasi layanan.' },
  { icon: Smartphone, title: 'Aktifkan izin & mulai bekerja', body: 'Izinkan lokasi dan notifikasi, lalu terima penugasan, checklist, dan laporan dari lapangan.' },
];

const FEATURES = [
  { name: 'Armada', body: 'Daftar unit kendaraan dan alat berat beserta status, dokumen, dan riwayatnya.' },
  { name: 'Operasional', body: 'Penugasan kerja, work order, dan jadwal servis yang terpantau dari satu layar.' },
  { name: 'Passport', body: 'Identitas digital peralatan: spesifikasi, sertifikasi, dan masa berlaku dokumen.' },
  { name: 'Digital', body: 'Checklist digital, laporan lapangan, dan notifikasi aktivitas secara real-time.' },
];

// Store listings are not published yet, so badges are labelled rather than linked (no dead links).
const STORES = [
  { src: badgeGooglePlay.url, alt: 'Segera hadir — Dapatkan di Google Play' },
  { src: badgeAppStore.url, alt: 'Segera hadir — Unduh di App Store' },
];

export function AppDownload() {
  return <section className="section" aria-labelledby="app-download-title">
    <Container className="grid grid-cols-[minmax(0,1fr)] gap-12 lg:grid-cols-[1fr_1.1fr] lg:gap-16">
      <Reveal>
        <p className="eyebrow">Aplikasi Mobile</p>
        <h2 id="app-download-title" className="text-headline mt-5">OPERTRACE di saku setiap operator.</h2>
        <p className="text-lead mt-5 text-muted-foreground">Pengemudi, mekanik, dan supervisor terhubung ke platform yang sama, langsung dari lapangan.</p>
        <div className="store-badges mt-8 flex flex-row items-center gap-3 sm:gap-4">
          {STORES.map(({ src, alt }) => <img key={alt} src={src} alt={alt} width={660} height={195} className="h-auto min-w-0 max-w-[172px] flex-1 rounded-full transition-all duration-300 hover:-translate-y-0.5" loading="lazy" />)}
        </div>
        <p className="mt-3 text-base text-muted-foreground">App Store & Google Play · Segera hadir</p>
        <ul className="mt-10 grid gap-x-8 gap-y-6 sm:grid-cols-2">
          {FEATURES.map(({ name, body }) => <li key={name} className="pt-4">
            <p className="font-semibold">{name}</p>
            <p className="mt-1 text-lg text-muted-foreground">{body}</p>
          </li>)}
        </ul>
      </Reveal>
      <Reveal delay={100}>
        <ol className="space-y-6">
          {STEPS.map(({ icon: I, title, body }) => <li key={title} className="flex gap-5 pt-6">
            
            <I className="mt-0.5 size-5 shrink-0 text-brand-text" />
            <div><p className="font-semibold">{title}</p><p className="mt-1 text-muted-foreground">{body}</p></div>
          </li>)}
        </ol>
      </Reveal>
    </Container>
  </section>;
}
