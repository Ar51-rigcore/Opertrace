import { useEffect, useState, type FormEvent } from 'react';
import { useServerFn } from '@tanstack/react-start';
import { CheckCircle2, LoaderCircle, Send, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { submitDemoRequest } from '@/lib/demo-requests.functions';
import { demoRequestSchema } from '@/lib/demo-request-schema';

type Field = 'name' | 'email' | 'fleetNeeds';

export function DemoRequestForm({ initialNeeds = '', idPrefix = 'demo' }: { initialNeeds?: string; idPrefix?: string }) {
  const submit = useServerFn(submitDemoRequest);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [fleetNeeds, setFleetNeeds] = useState(initialNeeds);
  const [website, setWebsite] = useState('');
  const [errors, setErrors] = useState<Partial<Record<Field, string>>>({});
  const [formError, setFormError] = useState('');
  const [pending, setPending] = useState(false);
  const [sent, setSent] = useState(false);

  useEffect(() => { if (initialNeeds) setFleetNeeds(initialNeeds); }, [initialNeeds]);

  async function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (pending) return;
    const parsed = demoRequestSchema.safeParse({ name, email, fleetNeeds, website });
    if (!parsed.success) {
      const next: Partial<Record<Field, string>> = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path[0] as Field;
        if (!next[key]) next[key] = issue.message;
      }
      setErrors(next);
      return;
    }
    setErrors({}); setFormError(''); setPending(true);
    try {
      const response = await submit({ data: parsed.data });
      if (response.ok) setSent(true); else setFormError(response.error ?? 'Permintaan belum terkirim.');
    } catch {
      setFormError('Koneksi terputus. Isian Anda tidak hilang; silakan coba kembali.');
    } finally { setPending(false); }
  }

  if (sent) return <div role="status" className="rounded-lg border border-hairline bg-card p-6 md:p-8">
    <CheckCircle2 className="size-8 text-status-success" />
    <h3 className="text-title mt-5">Permintaan demo diterima.</h3>
    <p className="mt-3 leading-relaxed text-muted-foreground">Terima kasih, {name.trim().split(' ')[0]}. Kebutuhan armada Anda telah tercatat untuk ditinjau tim OPERTRACE.</p>
    <Button variant="outline" className="mt-6 min-h-12" onClick={() => { setSent(false); setName(''); setEmail(''); setFleetNeeds(''); }}>Kirim permintaan lain</Button>
  </div>;

  const fieldClass = 'min-h-12 bg-card text-base';
  return <form onSubmit={onSubmit} noValidate className="space-y-5 rounded-lg border border-hairline bg-card/60 p-5 md:p-8">
    <div className="grid gap-5 sm:grid-cols-2">
      <div>
        <label htmlFor={`${idPrefix}-name`} className="mb-2 block font-medium">Nama lengkap</label>
        <Input id={`${idPrefix}-name`} value={name} onChange={e => setName(e.target.value)} autoComplete="name" maxLength={100} aria-invalid={!!errors.name} aria-describedby={errors.name ? `${idPrefix}-name-error` : undefined} className={fieldClass} />
        {errors.name && <p id={`${idPrefix}-name-error`} className="mt-2 text-sm text-destructive">{errors.name}</p>}
      </div>
      <div>
        <label htmlFor={`${idPrefix}-email`} className="mb-2 block font-medium">Email kerja</label>
        <Input id={`${idPrefix}-email`} type="email" inputMode="email" value={email} onChange={e => setEmail(e.target.value)} autoComplete="email" maxLength={255} aria-invalid={!!errors.email} aria-describedby={errors.email ? `${idPrefix}-email-error` : undefined} className={fieldClass} />
        {errors.email && <p id={`${idPrefix}-email-error`} className="mt-2 text-sm text-destructive">{errors.email}</p>}
      </div>
    </div>
    <div>
      <label htmlFor={`${idPrefix}-needs`} className="mb-2 block font-medium">Kebutuhan armada</label>
      <Textarea id={`${idPrefix}-needs`} value={fleetNeeds} onChange={e => setFleetNeeds(e.target.value)} rows={6} maxLength={4000} placeholder="Jenis dan jumlah unit, lokasi operasi, kendala saat ini, dan hasil yang ingin dicapai." aria-invalid={!!errors.fleetNeeds} aria-describedby={`${idPrefix}-needs-hint`} className="bg-card text-base" />
      <p id={`${idPrefix}-needs-hint`} className={`mt-2 text-sm ${errors.fleetNeeds ? 'text-destructive' : 'text-muted-foreground'}`}>{errors.fleetNeeds ?? 'Jangan sertakan kata sandi atau data rahasia.'}</p>
    </div>
    <div aria-hidden="true" className="absolute -left-[9999px] h-px w-px overflow-hidden">
      <label htmlFor={`${idPrefix}-website`}>Website</label>
      <input id={`${idPrefix}-website`} tabIndex={-1} autoComplete="off" value={website} onChange={e => setWebsite(e.target.value)} />
    </div>
    <Button type="submit" size="lg" disabled={pending} className="min-h-12 w-full rounded-md sm:w-auto">
      {pending ? <LoaderCircle className="animate-spin" /> : <Send />}{pending ? 'Mengirim…' : 'Kirim permintaan demo'}
    </Button>
    {formError && <p role="alert" className="flex gap-2 text-destructive"><ShieldAlert className="size-5 shrink-0" />{formError}</p>}
  </form>;
}
