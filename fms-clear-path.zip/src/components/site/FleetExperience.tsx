import { useEffect, useState } from 'react';
import { Link } from '@tanstack/react-router';
import { ArrowRight, CheckCircle2, Circle, Eye, Gauge, Pause, Play, Route, Sparkles, Truck, Zap, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import mine from '@/assets/industrial-mine.jpg';
import { Container } from './ui';

const UNITS = [
  { id: 'DT-024', location: 'South Pit', distance: '24,8 km', load: '182 ton', speed: '28 km/jam', eta: '14 menit' },
  { id: 'DT-031', location: 'North Pit', distance: '18,2 km', load: '164 ton', speed: '24 km/jam', eta: '21 menit' },
  { id: 'DT-018', location: 'Stockpile', distance: '12,6 km', load: '156 ton', speed: '22 km/jam', eta: '9 menit' },
];
const STAGES = ['Inspeksi', 'Dispatch', 'Hauling', 'Selesai'];
const STAGE_TITLE = ['Inspeksi unit', 'Penugasan diterima', 'Dalam perjalanan', 'Perjalanan selesai'];
const STEP_MS = 2800;

export function FleetExperience() {
  const [selected, setSelected] = useState(0);
  const [stage, setStage] = useState(2);
  const [playing, setPlaying] = useState(true);
  const unit = UNITS[selected] ?? UNITS[0];

  // Auto-advance the illustrative journey while playing; respects reduced motion.
  useEffect(() => {
    if (!playing || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const timer = window.setInterval(() => setStage(s => (s + 1) % STAGES.length), STEP_MS);
    return () => window.clearInterval(timer);
  }, [playing]);

  if (!unit) return null;
  const progress = (stage / (STAGES.length - 1)) * 100;

  return <section className="lens-workspace py-12 md:py-20" aria-labelledby="fleet-title">
    <Container>
      <div className="flex flex-wrap items-end justify-between gap-5">
        <div><p className="eyebrow">Alur kerja OPERTRACE</p><h2 id="fleet-title" className="text-headline mt-3">Dari visibilitas ke eksekusi.</h2><p className="mt-4 max-w-xl leading-relaxed text-muted-foreground">Data lapangan. Wawasan yang dapat ditindaklanjuti. Operasi yang bergerak.</p></div>
        <span className="flex items-center gap-2 text-xs text-muted-foreground"><Circle className="size-2 fill-current" />Simulasi armada</span>
      </div>
      <div className="mt-9 grid gap-8 lg:grid-cols-[1.65fr_1fr]">
        <div className="min-w-0">
          <div className="grid grid-cols-3 gap-3 py-5 md:py-6">
            {[{ icon: Eye, title: 'SEE', body: 'Lihat kondisi operasi' }, { icon: Zap, title: 'UNDERSTAND', body: 'Temukan makna data' }, { icon: ShieldCheck, title: 'ACT', body: 'Tindak lanjut terukur' }].map(item => <div key={item.title} className="flex min-w-0 flex-col gap-2 sm:flex-row sm:gap-3"><item.icon className="size-5 shrink-0 text-brand-text" /><div className="min-w-0"><p className="text-xs font-semibold sm:text-sm">{item.title}</p><p className="mt-1 text-xs leading-relaxed text-muted-foreground">{item.body}</p></div></div>)}
          </div>

          <div className="-mx-6 mt-6 flex snap-x gap-2 overflow-x-auto px-6 pb-1 [scrollbar-width:none] sm:mx-0 sm:flex-wrap sm:px-0" role="group" aria-label="Pilih unit armada">
            {UNITS.map((item, index) => <Button key={item.id} variant={selected === index ? 'secondary' : 'outline'} aria-pressed={selected === index} onClick={() => { setSelected(index); setStage(0); setPlaying(true); }} className={`min-h-11 shrink-0 snap-start gap-2 rounded-full px-4 transition-all duration-300 active:scale-[0.97] ${selected === index ? 'ring-2 ring-primary/60' : ''}`}><Truck className="size-4" />{item.id}<span className="text-xs text-muted-foreground">{item.location}</span></Button>)}
          </div>

          <div className="mt-5 grid gap-6 sm:grid-cols-[.8fr_1.2fr]">
            <div className="relative min-h-44 overflow-hidden rounded-md"><img src={mine} alt="Haul truck pada jalur operasional pertambangan" loading="lazy" width={1920} height={1024} className="fleet-photo absolute inset-0 h-full w-full object-cover" /><span className="absolute bottom-3 left-3 rounded bg-cover-background px-3 py-1 text-xs text-cover-foreground">Haul Truck · {unit.id}</span></div>
            <div aria-live="polite">
              <p className="text-xs text-muted-foreground">{unit.id} / {unit.location}</p>
              <h3 className="mt-2 flex items-center gap-2 text-lg font-semibold"><CheckCircle2 className="size-5 text-status-success" />{STAGE_TITLE[stage]}</h3>
              <div className="relative mt-5" role="group" aria-label="Tahap perjalanan">
                <span aria-hidden="true" className="absolute top-[22px] right-[12.5%] left-[12.5%] h-0.5 rounded-full bg-border" />
                <span aria-hidden="true" className="absolute top-[22px] left-[12.5%] h-0.5 rounded-full bg-primary transition-all duration-700 ease-out" style={{ width: `${progress * 0.75}%` }} />
                <div className="relative grid grid-cols-4">
                  {STAGES.map((label, index) => <div key={label} className="flex min-w-0 flex-col items-center gap-2">
                    <Button size="icon" variant={stage === index ? 'default' : 'outline'} aria-label={`Tahap ${label}`} aria-pressed={stage === index} onClick={() => { setStage(index); setPlaying(false); }} className={`size-11 rounded-full transition-all duration-300 active:scale-95 ${stage === index ? 'shadow-glow' : 'bg-card'}`}>{index < stage ? <CheckCircle2 /> : <Circle />}</Button>
                    <span className={`text-xs ${stage === index ? 'font-semibold text-foreground' : 'text-muted-foreground'}`}>{label}</span>
                  </div>)}
                </div>
              </div>
              <dl className="mt-6 grid grid-cols-2 gap-4">{[['Jarak tempuh', unit.distance], ['Muatan', stage === 0 ? '0 ton' : unit.load], ['Kecepatan', stage === 3 || stage === 0 ? '0 km/jam' : unit.speed], ['ETA tujuan', stage === 3 ? 'Tiba' : unit.eta]].map(([label, value]) => <div key={label}><dt className="text-xs text-muted-foreground">{label}</dt><dd className="critical-data mt-1 text-sm font-semibold">{value}</dd></div>)}</dl>
            </div>
          </div>
        </div>

        <div className="overflow-hidden rounded-md bg-card shadow-card">
          <div className="flex items-center justify-between px-5 py-3"><h3 className="flex items-center gap-2 text-sm font-semibold"><Route className="size-4 text-brand-text" />Fleet Live &amp; Dispatch</h3><Button size="icon" variant="ghost" className="size-11" onClick={() => setPlaying(value => !value)} aria-label={playing ? 'Jeda simulasi' : 'Putar simulasi'} title={playing ? 'Jeda simulasi' : 'Putar simulasi'}>{playing ? <Pause /> : <Play />}</Button></div>
          <div className="relative mx-4 aspect-[1.5] overflow-hidden rounded-sm bg-cover-background">
            <img src={mine} alt="Visualisasi rute dari area pit menuju crusher" loading="lazy" width={1920} height={1024} className="absolute inset-0 h-full w-full object-cover opacity-60" />
            <svg viewBox="0 0 400 260" className="absolute inset-0 h-full w-full" aria-hidden="true"><path id="fleet-route" d="M40 214 C90 212 75 135 140 136 S223 201 246 114 S300 72 354 48" className="fleet-route-path" fill="none" strokeWidth="3" /><circle r="7" className={`fleet-route-dot ${playing ? '' : 'fleet-paused'}`} /><circle cx="40" cy="214" r="5" className="fleet-endpoint" /><circle cx="354" cy="48" r="5" className="fleet-endpoint" /></svg>
            <span className="absolute bottom-3 left-3 text-xs font-medium text-cover-foreground">{unit.location}</span><span className="absolute top-3 right-3 text-xs font-medium text-cover-foreground">Crusher Area</span>
          </div>
          <dl className="grid grid-cols-3 px-4 py-5">{[['12', 'Unit aktif'], ['3', 'Dalam antrean'], ['420', 'Produksi (ton)']].map(([value, label]) => <div key={label} className="px-3"><dd className="critical-data text-xl font-semibold">{value}</dd><dt className="mt-1 text-xs text-muted-foreground">{label}</dt></div>)}</dl>
          <Link to="/fleet-planner" className="group flex min-h-12 items-center gap-2 px-5 py-3 text-sm font-medium transition-colors hover:bg-accent"><Sparkles className="size-4 text-brand-text" />Rancang alur armada Anda dengan AI<ArrowRight className="ml-auto size-4 transition-transform duration-300 group-hover:translate-x-1" /></Link>
          <p className="flex items-center gap-2 px-5 pb-3 text-xs text-muted-foreground"><Gauge className="size-4" />Data ilustratif · Bukan pemantauan langsung</p>
        </div>
      </div>
    </Container>
  </section>;
}
