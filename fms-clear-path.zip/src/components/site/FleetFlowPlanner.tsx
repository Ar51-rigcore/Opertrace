import { useRef, useState, type FormEvent } from 'react';
import { useServerFn } from '@tanstack/react-start';
import { ArrowRight, CircleHelp, Eye, LoaderCircle, ShieldAlert, ShieldCheck, Sparkles, Workflow, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { recommendFleetFlow } from '@/lib/fleet-flow.functions';
import { fleetNeedsSchema, type FleetFlow } from '@/lib/fleet-flow-schema';
import { DemoRequestForm } from './DemoRequestForm';

const EXAMPLES = [
  { industry: 'Pertambangan', fleetSize: '40 haul truck, 8 excavator', needs: 'Antrean di area loading sering panjang, ritase per shift tidak tercatat rapi, dan downtime unit baru diketahui setelah laporan harian.' },
  { industry: 'Logistik', fleetSize: '120 truk antarkota', needs: 'Perjalanan kosong saat kembali tinggi, bukti pengiriman masih kertas, dan biaya perjalanan sulit direkonsiliasi dengan invoice.' },
  { industry: 'Perkebunan', fleetSize: '60 dump truck dan traktor', needs: 'Pengangkutan TBS dari blok ke pabrik tidak terjadwal dengan baik dan perawatan unit sering terlambat saat musim panen.' },
];
const PHASE_ICON = { SEE: Eye, UNDERSTAND: Zap, ACT: ShieldCheck } as const;

export function FleetFlowPlanner() {
  const plan = useServerFn(recommendFleetFlow);
  const [industry, setIndustry] = useState('');
  const [fleetSize, setFleetSize] = useState('');
  const [needs, setNeeds] = useState('');
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<FleetFlow | null>(null);
  const [demoNeeds, setDemoNeeds] = useState('');
  const demoRef = useRef<HTMLDivElement>(null);
  const resultRef = useRef<HTMLDivElement>(null);

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (pending) return;
    const input = fleetNeedsSchema.safeParse({ industry, fleetSize, needs });
    if (!input.success) { setError(input.error.issues[0]?.message ?? 'Lengkapi formulir.'); return; }
    setError(''); setResult(null); setDemoNeeds(''); setPending(true);
    requestAnimationFrame(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
    try {
      const response = await plan({ data: input.data });
      setResult(response.result); setError(response.error ?? '');
    } catch { setError('Koneksi terputus. Isian Anda tidak hilang; silakan coba kembali nanti.'); }
    finally { setPending(false); }
  }

  function requestDemo() {
    if (!result) return;
    const flow = result.stages.map((s, i) => `${i + 1}. ${s.title} (${s.domain})`).join('\n');
    setDemoNeeds(`Industri: ${industry}\n${fleetSize ? `Armada: ${fleetSize}\n` : ''}Kebutuhan: ${needs}\n\nAlur rekomendasi AI:\n${flow}`.slice(0, 4000));
    requestAnimationFrame(() => demoRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
  }

  return <div className="grid grid-cols-[minmax(0,1fr)] items-start gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.15fr)]">
    <form onSubmit={submit} className="min-w-0 space-y-5">
      <div>
        <p className="mb-3 text-sm text-muted-foreground">Mulai dari contoh</p>
        <div className="-mx-6 flex snap-x gap-2 overflow-x-auto px-6 pb-1 [scrollbar-width:none] sm:mx-0 sm:flex-wrap sm:px-0">
          {EXAMPLES.map(example => <Button key={example.industry} type="button" variant="outline" className="min-h-11 shrink-0 snap-start rounded-full" onClick={() => { setIndustry(example.industry); setFleetSize(example.fleetSize); setNeeds(example.needs); setError(''); }}>{example.industry}</Button>)}
        </div>
      </div>
      <div className="grid gap-5 sm:grid-cols-2">
        <div><label htmlFor="flow-industry" className="mb-2 block font-medium">Industri</label><Input id="flow-industry" value={industry} onChange={e => setIndustry(e.target.value)} maxLength={100} placeholder="Contoh: konstruksi" className="min-h-12 bg-card text-base" /></div>
        <div><label htmlFor="flow-size" className="mb-2 block font-medium">Skala armada <span className="font-normal text-muted-foreground">(opsional)</span></label><Input id="flow-size" value={fleetSize} onChange={e => setFleetSize(e.target.value)} maxLength={120} placeholder="Contoh: 25 dump truck" className="min-h-12 bg-card text-base" /></div>
      </div>
      <div><label htmlFor="flow-needs" className="mb-2 block font-medium">Kebutuhan operasional</label><Textarea id="flow-needs" value={needs} onChange={e => setNeeds(e.target.value)} maxLength={4000} rows={6} placeholder="Apa yang terjadi di lapangan, di mana hambatannya, dan hasil apa yang ingin Anda capai?" className="bg-card text-base" /><p className="mt-2 text-sm text-muted-foreground">Jangan sertakan kata sandi, data pribadi, atau informasi rahasia.</p></div>
      <Button type="submit" size="lg" disabled={pending} className="min-h-12 w-full rounded-md sm:w-auto">{pending ? <LoaderCircle className="animate-spin" /> : <Sparkles />}{pending ? 'Menyusun alur armada…' : 'Susun alur armada'}</Button>
      {error && <p role="alert" className="flex gap-2 text-destructive"><ShieldAlert className="size-5 shrink-0" />{error}</p>}
    </form>

    <div ref={resultRef} aria-live="polite" aria-busy={pending} className="min-w-0 scroll-mt-24 pt-6 lg:pl-12 lg:pt-0">
      {pending ? <div role="status" className="space-y-4">
        <p className="flex items-center gap-2 text-muted-foreground"><LoaderCircle className="size-5 animate-spin" />Memetakan kebutuhan ke alur SEE → UNDERSTAND → ACT…</p>
        {[0, 1, 2, 3].map(i => <div key={i} className="h-20 animate-pulse rounded-md bg-muted" />)}
      </div> : result ? <div className="space-y-6">
        <div className="inline-flex items-center gap-2 rounded-md bg-status-info-bg px-3 py-2 text-sm font-medium text-status-info"><CircleHelp className="size-4" />Rekomendasi awal · Perlu validasi</div>
        <h3 className="text-title">Alur armada yang disarankan</h3>
        <p className="critical-data rounded-md p-4 leading-relaxed">{result.summary}</p>
        {result.stages.length > 0 && <ol className="relative space-y-0">
          {result.stages.map((stage, i) => { const Icon = PHASE_ICON[stage.phase]; return <li key={`${stage.title}-${i}`} className="relative flex gap-4 pb-7 last:pb-0">
            {i < result.stages.length - 1 && <span aria-hidden="true" className="absolute top-11 bottom-0 left-[21px] w-px bg-border" />}
            <span className="relative z-10 flex size-11 shrink-0 items-center justify-center rounded-full border border-hairline bg-card"><Icon className="size-5 text-brand-text" /></span>
            <div className="min-w-0 pt-1">
              <p className="text-xs font-semibold tracking-wide text-brand-text">{String(i + 1).padStart(2, '0')} · {stage.phase}</p>
              <h4 className="mt-1 font-semibold">{stage.title}</h4>
              <p className="mt-2 leading-relaxed text-muted-foreground">{stage.action}</p>
              <dl className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
                <div><dt className="text-muted-foreground">Domain</dt><dd className="font-medium">{stage.domain}</dd></div>
                <div><dt className="text-muted-foreground">Indikator</dt><dd className="font-medium">{stage.metric}</dd></div>
              </dl>
            </div>
          </li>; })}
        </ol>}
        {result.questions.length > 0 && <div><h4 className="font-semibold">Perlu dikonfirmasi</h4><ul className="mt-3 list-disc space-y-2 pl-5 text-muted-foreground">{result.questions.map(q => <li key={q}>{q}</li>)}</ul></div>}
        <p className="flex gap-2 rounded-md bg-status-warning-bg p-4 text-sm leading-relaxed text-status-warning"><ShieldAlert className="mt-0.5 size-5 shrink-0" />{result.caution}</p>
        {result.stages.length > 0 && <Button size="lg" onClick={requestDemo} className="min-h-12 w-full rounded-md sm:w-auto">Minta demo dengan alur ini <ArrowRight /></Button>}
      </div> : <div>
        <p className="eyebrow">OPERTRACE · Fleet Flow AI</p>
        <h3 className="text-title mt-4">Alur armada yang sesuai operasi Anda.</h3>
        <p className="mt-4 leading-relaxed text-muted-foreground">Jelaskan kebutuhan. AI menyusun tahapan kerja dari visibilitas sampai eksekusi, hanya dari domain OPERTRACE yang tersedia.</p>
        <div className="mt-8 space-y-4 pt-6">{[[Eye, 'SEE — Lihat posisi dan status unit'], [Zap, 'UNDERSTAND — Temukan penyebab hambatan'], [ShieldCheck, 'ACT — Tindak lanjut yang tercatat']].map(([Icon, label]) => { const I = Icon as typeof Eye; return <p key={label as string} className="flex gap-3"><I className="size-5 shrink-0 text-brand-text" />{label as string}</p>; })}</div>
        <p className="mt-8 flex items-center gap-2 text-sm text-muted-foreground"><Workflow className="size-4" />Tidak ada data yang disimpan dari perencana ini.</p>
      </div>}
    </div>

    {demoNeeds && <div ref={demoRef} className="scroll-mt-24 lg:col-span-2">
      <p className="eyebrow">Langkah berikutnya</p>
      <h3 className="text-headline mt-3 max-w-2xl">Minta demo dengan alur ini.</h3>
      <div className="mt-8"><DemoRequestForm initialNeeds={demoNeeds} idPrefix="flow-demo" /></div>
    </div>}
  </div>;
}
