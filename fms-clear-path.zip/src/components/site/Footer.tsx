import { Link } from "@tanstack/react-router";
import { Container, Logo } from "./ui";
import { COMPANY_CONTACT } from "@/lib/company-contact";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

const FOOTER_COLUMNS: { heading: string; links: { label: string; to: string }[] }[] = [
  {
    heading: "Perusahaan",
    links: [
      { label: "Beranda", to: "/" },
      { label: "Tentang Kami", to: "/about" },
      { label: "Visi & Misi", to: "/vision" },
      { label: "Tim Kami", to: "/team" },
      { label: "Kontak", to: "/contact" },
    ],
  },
  {
    heading: "Solusi",
    links: [
      { label: "Teknologi Digital", to: "/platform" },
      { label: "Operasi Industri", to: "/platform" },
      { label: "Intelijen Aset & Armada", to: "/platform" },
      { label: "Komers Industri", to: "/platform" },
      { label: "Business Intelligence", to: "/technology" },
      { label: "Integrasi Enterprise", to: "/platform" },
    ],
  },
  {
    heading: "OPERTRACE",
    links: [
      { label: "Ikhtisar Platform", to: "/platform" },
      { label: "Fleet Management", to: "/platform" },
      { label: "Asset Management", to: "/platform" },
      { label: "Industrial Marketplace", to: "/platform" },
      { label: "Industrial Intelligence", to: "/platform" },
      { label: "Minta Demo", to: "/demo" },
      { label: "Perencana Alur Armada AI", to: "/fleet-planner" },
      { label: "Panduan Alur Armada", to: "/fleet-guide" },
    ],
  },
  {
    heading: "Industri",
    links: [
      { label: "Pertambangan", to: "/industries" },
      { label: "Konstruksi", to: "/industries" },
      { label: "Perkebunan", to: "/industries" },
      { label: "Energi", to: "/industries" },
      { label: "Logistik", to: "/industries" },
      { label: "Manufaktur", to: "/industries" },
    ],
  },
  {
    heading: "Terhubung",
    links: [
      { label: "Business Inquiry", to: "/contact" },
      { label: "Kemitraan Strategis", to: "/contact" },
      { label: "Investasi", to: "/contact" },
      { label: "Karier", to: "/team" },
      { label: "Masuk / Daftar", to: "/login" },
    ],
  },
];

/**
 * Semantic global footer: brand statement, organized multi-column
 * navigation, legal row, and copyright declaration.
 */
export function Footer() {
  return (
    <footer className="bg-secondary/20">
      <Container className="py-16">
        <div className="grid grid-cols-2 gap-x-6 gap-y-10 md:grid-cols-3 xl:grid-cols-[1.5fr_repeat(5,1fr)]">
          <div className="col-span-2 md:col-span-3 xl:col-span-1">
            <Logo />
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-muted-foreground">
              Building Intelligent Solutions. Connecting Industrial Opportunities.
            </p>
            <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
              PT Cakrakarsa Aditama Nusantara mengembangkan solusi teknologi dan ekosistem digital
              untuk mendukung transformasi bisnis, operasional industri, dan pertumbuhan
              berkelanjutan.
            </p>
            <address className="mt-5 space-y-1 text-xs not-italic leading-relaxed text-muted-foreground">
              <p>{COMPANY_CONTACT.address}</p>
              <p><a href={COMPANY_CONTACT.phoneHref} className="hover:text-brand-text">{COMPANY_CONTACT.phone}</a></p>
              {COMPANY_CONTACT.emails.map(e => <p key={e.value}><a href={`mailto:${e.value}`} className="hover:text-brand-text">{e.value}</a></p>)}
              <p><a href={COMPANY_CONTACT.websiteHref} target="_blank" rel="noopener noreferrer" className="hover:text-brand-text">{COMPANY_CONTACT.website}</a></p>
            </address>
          </div>
          <Accordion type="multiple" className="col-span-2 md:hidden">
            {FOOTER_COLUMNS.map((col) => (
              <AccordionItem key={col.heading} value={col.heading} className="border-0">
                <AccordionTrigger className="min-h-14 text-xs font-semibold uppercase text-foreground hover:no-underline">
                  {col.heading}
                </AccordionTrigger>
                <AccordionContent>
                <nav aria-label={`Tautan ${col.heading}`}>
                  <ul className="grid grid-cols-2 gap-x-4 pb-5">
                    {col.links.map((link) => (
                      <li key={link.label}>
                        <Link to={link.to} className="inline-flex min-h-11 items-center text-sm text-muted-foreground transition-colors duration-300 hover:text-brand-text">{link.label}</Link>
                      </li>
                    ))}
                  </ul>
                </nav>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          {FOOTER_COLUMNS.map((col) => (
            <nav key={col.heading} aria-label={`Tautan ${col.heading}`} className="hidden md:block">
              <h2 className="text-xs font-semibold uppercase text-foreground">
                {col.heading}
              </h2>
              <ul className="mt-5 space-y-3">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      to={link.to}
                      className="inline-flex min-h-9 items-center text-sm leading-relaxed text-muted-foreground transition-colors duration-300 hover:text-brand-text"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 pt-8 text-xs text-muted-foreground md:flex-row">
          <p>© 2026 PT Cakrakarsa Aditama Nusantara. All Rights Reserved.</p>
          <nav aria-label="Tautan legal" className="flex flex-wrap items-center gap-5">
            <Link to="/legal" className="transition-all duration-300 hover:text-foreground">
              Privacy Policy
            </Link>
            <Link to="/legal" className="transition-all duration-300 hover:text-foreground">
              Terms &amp; Conditions
            </Link>
            <Link to="/legal" className="transition-all duration-300 hover:text-foreground">
              Cookie Policy
            </Link>
            <Link to="/legal" className="transition-all duration-300 hover:text-foreground">
              Corporate Information
            </Link>
          </nav>
        </div>
        <p className="mt-6 text-center text-xs text-muted-foreground md:text-left">
          OPERTRACE — One Platform. Total Fleet Control.
        </p>
      </Container>
    </footer>
  );
}
