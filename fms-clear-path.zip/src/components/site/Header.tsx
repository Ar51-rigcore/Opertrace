import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, ChevronDown, Menu, Sparkles } from "lucide-react";
import { Container, Logo } from "./ui";
import { ThemeToggle } from './ThemeToggle';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetDescription, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

const NAV_LINKS = [
  { label: "Platform", to: "/platform" },
  { label: "Alur Armada AI", to: "/fleet-planner" },
  { label: "Panduan Armada", to: "/fleet-guide" },
  { label: "Industri", to: "/industries" },
  { label: "Teknologi", to: "/technology" },
  { label: "Tim", to: "/team" },
  { label: "Tentang Kami", to: "/about" },
  { label: "Kontak", to: "/contact" },
];

/** Pages that open with the full-bleed industrial photo; the header floats over it. */
const PHOTO_ROUTES = new Set(["/", "/platform", "/about", "/technology", "/industries", "/contact", "/demo", "/fleet-guide", "/vision", "/team", "/fleet-planner", "/login", "/legal"]);

/**
 * Fixed header: transparent over photo openings, solid after the first scroll.
 * A hairline progress rule shows reading position on every page.
 */
export function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const path = useRouterState({ select: s => s.location.pathname });
  const overPhoto = PHOTO_ROUTES.has(path);
  useEffect(() => { setOpen(false); }, [path]);

  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      const y = window.scrollY;
      setScrolled(y > 24);

    };
    const onScroll = () => { if (!frame) frame = requestAnimationFrame(update); };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll);
    return () => { window.removeEventListener('scroll', onScroll); window.removeEventListener('resize', onScroll); if (frame) cancelAnimationFrame(frame); };
  }, [path]);

  const cover = overPhoto && !scrolled && !open;

  return (
    <>
      <header data-cover={cover} data-scrolled={scrolled} className="site-header fixed inset-x-0 top-0 z-50">
        <Container className="flex h-20 items-center justify-between gap-3">
          <Logo />

          <nav aria-label="Navigasi utama" className="hidden items-center gap-1 xl:flex">
            {NAV_LINKS.slice(0, 5).map((link) => (
              <Link
                key={link.to}
                to={link.to}
                activeProps={{ className: "text-foreground after:scale-x-100" }}
                inactiveProps={{ className: "text-muted-foreground" }}
                className="header-link relative rounded-md px-2.5 py-2 text-sm transition-colors duration-300 after:absolute after:inset-x-2.5 after:bottom-0.5 after:h-0.5 after:origin-left after:scale-x-0 after:rounded-full after:bg-primary after:transition-transform after:duration-300 hover:text-foreground hover:after:scale-x-100"
              >
                {link.label}
              </Link>
            ))}
            <DropdownMenu>
              <DropdownMenuTrigger asChild><Button variant="ghost" className="header-link min-h-11 gap-1 px-3 text-sm">Perusahaan <ChevronDown className="size-3.5" /></Button></DropdownMenuTrigger>
              <DropdownMenuContent align="start" sideOffset={18} className="w-64 border-hairline bg-popover p-2">
                {[...NAV_LINKS.slice(5), { label: 'Visi & Misi', to: '/vision' }].map(link => <DropdownMenuItem key={link.to} asChild><Link to={link.to} className="min-h-12 justify-between px-3">{link.label}<ArrowRight className="size-4" /></Link></DropdownMenuItem>)}
              </DropdownMenuContent>
            </DropdownMenu>
          </nav>

          <div className="header-actions flex items-center gap-2">
            <ThemeToggle />
            <div className="hidden items-center gap-2 sm:flex">
              <Button asChild className="min-h-11 rounded-md px-4"><Link to="/demo">Minta Demo <ArrowRight className="size-4" /></Link></Button>
            </div>
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" aria-label="Buka menu navigasi" className="header-menu min-h-11 min-w-11 xl:hidden">
                  <Menu className="size-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="flex h-dvh max-h-dvh w-full flex-col gap-0 border-hairline bg-background p-0 sm:max-w-sm">
                <div className="flex h-20 items-center px-6">
                  <SheetTitle className="text-base">Menu</SheetTitle>
                  <SheetDescription className="sr-only">Navigasi situs OPERTRACE</SheetDescription>
                </div>
                <nav aria-label="Navigasi seluler" className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-3 py-4">
                  {[...NAV_LINKS, { label: 'Visi & Misi', to: '/vision' }].map((link) => (
                    <Link
                      key={link.to}
                      to={link.to}
                      activeProps={{ className: "bg-accent text-foreground" }}
                      inactiveProps={{ className: "text-muted-foreground" }}
                      className="flex min-h-14 items-center justify-between rounded-md px-3 text-lg font-medium transition-colors duration-200 hover:bg-accent hover:text-foreground active:scale-[0.99]"
                    >
                      <span className="flex min-w-0 items-center gap-3">{link.label}{link.to === "/fleet-planner" && <Sparkles className="size-4 shrink-0 text-brand-text" />}</span>
                      <ArrowRight className="size-4 opacity-50" />
                    </Link>
                  ))}
                </nav>
                <div className="grid gap-2 p-4 pb-[max(1rem,env(safe-area-inset-bottom))]">
                  <Button asChild size="lg" className="min-h-12 rounded-md"><Link to="/demo">Minta Demo <ArrowRight /></Link></Button>
                  <Button asChild variant="outline" size="lg" className="min-h-12 rounded-md"><Link to="/login">Masuk</Link></Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </Container>
      </header>
      {!overPhoto && <div aria-hidden="true" className="h-20" />}
    </>
  );
}
