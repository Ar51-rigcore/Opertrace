import { ArrowRight } from 'lucide-react';
import { Link } from '@tanstack/react-router';
import horizon from '@/assets/horizon-nusantara.jpg';
import mining from '@/assets/ind-mining.jpg';
import logistics from '@/assets/ind-logistics.jpg';
import plantation from '@/assets/ind-plantation.jpg';
import { Button } from '@/components/ui/button';
import { Container, Reveal } from './ui';
import { HorizonMotion } from './HorizonMotion';

const SERVICES = [
  { title: 'Pertambangan', body: 'Armada lebih produktif, operasi lebih aman.', image: mining, alt: 'Haul truck membawa batu bara di jalan tambang saat senja' },
  { title: 'Logistik Maritim', body: 'Rantai pasok terhubung, pergerakan lebih efisien.', image: logistics, alt: 'Kapal kontainer dan truk di pelabuhan saat matahari terbenam' },
  { title: 'Perkebunan', body: 'Operasi terpantau, hasil lebih berkelanjutan.', image: plantation, alt: 'Truk pengangkut buah sawit melintasi perkebunan dari udara' },
];

/** Home opening: Earth-from-orbit horizon over the archipelago, centered message, then three service tiles. */
export function HorizonHero() {
  return <>
    <section className="horizon-hero flex flex-col" aria-labelledby="hero-title">
      <img src={horizon} alt="Kepulauan Indonesia dilihat dari orbit dengan jalur cahaya yang menghubungkan pusat operasi" width={1920} height={1088} fetchPriority="high" />
      <HorizonMotion />
      <Container className="flex flex-1 flex-col items-center pt-36 text-center md:pt-44">
        <p className="hero-rise type-label text-cover-muted">Satu platform untuk operasi fisik Indonesia</p>
        <h1 id="hero-title" className="mt-6 max-w-4xl text-cover-foreground">
          <span className="horizon-line"><span style={{ animationDelay: '150ms' }}>Satu Nusantara.</span></span>
          <span className="horizon-line"><span style={{ animationDelay: '380ms' }}>Satu Kendali Armada.</span></span>
        </h1>
        <p className="hero-rise type-body mt-6 max-w-xl text-cover-muted" style={{ animationDelay: '620ms' }}>Tambang, pelabuhan, dan perkebunan memiliki ritmenya sendiri. OPERTRACE menghubungkan aset, armada, dan aktivitasnya dalam satu alur—agar kendali tidak berhenti pada batas lokasi.</p>
        <div className="hero-rise mt-8 flex w-full flex-col items-center gap-4 sm:w-auto sm:flex-row" style={{ animationDelay: '800ms' }}>
          <Button asChild size="lg" className="h-12 w-full rounded-full px-7 transition-all duration-300 hover:-translate-y-0.5 active:scale-[0.98] sm:w-auto"><Link to="/demo">Minta Demo <ArrowRight /></Link></Button>
          <Button asChild variant="outline" size="lg" className="cover-outline h-12 w-full rounded-full px-7 transition-all duration-300 hover:-translate-y-0.5 active:scale-[0.98] sm:w-auto"><Link to="/platform">Jelajahi Platform <ArrowRight /></Link></Button>
        </div>
      </Container>
    </section>
    <section className="horizon-services py-10 md:py-16" aria-label="Layanan utama">
      <Container>
        <ul className="grid gap-10 md:grid-cols-3 md:gap-8">
          {SERVICES.map((s, i) => <li key={s.title}>
            <Reveal delay={i * 100}>
              <Link to="/industries" className="service-tile group block text-center">
                <span className="service-image block aspect-[16/9] overflow-hidden"><img src={s.image} alt={s.alt} width={1280} height={896} loading="lazy" className="h-full w-full object-cover" /></span>
                <span className="mt-5 block px-3">
                  <span className="type-title block text-3xl text-foreground">{s.title}</span>
                  <span className="mx-auto mt-3 block max-w-xs text-lg leading-relaxed text-muted-foreground">{s.body}</span>
                  <span className="mt-4 inline-flex min-h-11 items-center gap-2 text-sm font-medium text-brand-text">Lihat solusi <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" /></span>
                </span>
              </Link>
            </Reveal>
          </li>)}
        </ul>
      </Container>
    </section>
  </>;
}
