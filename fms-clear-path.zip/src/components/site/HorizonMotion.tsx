import { useId } from 'react';

/**
 * Decorative motion for the Horizon Nusantara language: a breathing atmosphere,
 * a dawn glow and light routes drawing between illustrative island hubs.
 * Purely illustrative — never represents live telemetry.
 */
const NODES = [
  { x: 250, y: 640 }, // Sumatra
  { x: 560, y: 770 }, // Jawa barat
  { x: 790, y: 790 }, // Jawa timur
  { x: 860, y: 560 }, // Kalimantan
  { x: 1030, y: 690 }, // Sulawesi
  { x: 1380, y: 650 }, // Papua
];

const ROUTES = [
  'M250 640 Q400 600 560 770',
  'M560 770 Q680 730 790 790',
  'M560 770 Q680 560 860 560',
  'M860 560 Q960 560 1030 690',
  'M790 790 Q930 700 1030 690',
  'M1030 690 Q1210 560 1380 650',
];

const STARS = Array.from({ length: 22 }, (_, i) => ({
  left: `${(i * 37 + 11) % 100}%`,
  top: `${(i * 23 + 5) % 30}%`,
  delay: `${(i * 0.7) % 5}s`,
}));

export function HorizonMotion({ compact = false }: { compact?: boolean }) {
  const uid = useId().replace(/:/g, '');
  const stars = compact ? STARS.slice(0, 12) : STARS;
  return (
    <div className={`horizon-motion${compact ? ' is-compact' : ''}`} aria-hidden="true">
      {stars.map((s, i) => (
        <span key={i} className="horizon-star" style={{ left: s.left, top: s.top, animationDelay: s.delay }} />
      ))}
      <svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMax slice">
        {ROUTES.map((d, i) => (
          <path key={d} id={`${uid}-route-${i}`} d={d} pathLength={1} className="horizon-route" style={{ animationDelay: `${0.6 + i * 0.25}s` }} />
        ))}
        {NODES.map((n, i) => (
          <g key={i}>
            <circle cx={n.x} cy={n.y} r={9} className="horizon-node-ring" style={{ animationDelay: `${i * 0.5}s` }} />
            <circle cx={n.x} cy={n.y} r={3.5} className="horizon-node" />
          </g>
        ))}
        {ROUTES.map((_, i) => (
          <circle key={i} r={3} className="horizon-pulse">
            <animateMotion dur={`${6 + i}s`} begin={`${2.4 + i * 0.4}s`} repeatCount="indefinite" rotate="auto">
              <mpath href={`#${uid}-route-${i}`} />
            </animateMotion>
          </circle>
        ))}
      </svg>
    </div>
  );
}
