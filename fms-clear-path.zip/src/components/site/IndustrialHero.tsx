import { ArrowDown, ArrowRight } from 'lucide-react';
import { Link } from '@tanstack/react-router';
import mine from '@/assets/industrial-mine.jpg';
import { Button } from '@/components/ui/button';
import { Container } from './ui';

export function IndustrialHero({ platform = false }: { platform?: boolean }) {
  return <section className="industrial-hero relative isolate flex flex-col overflow-hidden" aria-labelledby="hero-title">
    <img src={mine} alt="Visualisasi lokasi pertambangan dengan armada haul truck dan fasilitas pengolahan" width={1920} height={1024} fetchPriority="high" className="cinematic absolute inset-0 -z-20 h-full w-full object-cover" />
    <div className="industrial-veil absolute inset-0 -z-10" />
    <Container className="relative flex flex-1 flex-col justify-center pt-28 pb-10 md:pt-32">
      <p className="hero-rise type-label flex items-center gap-3 text-cover-muted"><span className="h-px w-8 bg-primary" />{platform ? '24 domain. Satu ekosistem.' : 'Physical Operations Intelligence'}</p>
      <h1 id="hero-title" className="hero-rise mt-7 max-w-2xl text-4xl font-semibold leading-[1.05] text-cover-foreground md:text-6xl" style={{ animationDelay: '80ms' }}>One Platform.<br /> Total Fleet Control.</h1>
      <p className="hero-rise mt-6 type-body max-w-md text-cover-muted" style={{ animationDelay: '160ms' }}>Menghubungkan aset, armada, dan aktivitas operasional. Dari data lapangan hingga keputusan yang dapat ditelusuri.</p>
      <div className="hero-rise mt-10 flex flex-col gap-4 sm:flex-row sm:gap-5" style={{ animationDelay: '240ms' }}>
        <Button asChild size="lg" className="h-12 w-full rounded-md px-6 transition-all duration-300 hover:-translate-y-0.5 active:scale-[0.98] sm:w-auto"><Link to="/demo">Minta Demo <ArrowRight /></Link></Button>
        <Button asChild variant="outline" size="lg" className="cover-outline h-12 w-full rounded-md px-6 transition-all duration-300 hover:-translate-y-0.5 active:scale-[0.98] sm:w-auto"><Link to={platform ? '/industries' : '/platform'}>{platform ? 'Jelajahi Industri' : 'Jelajahi Platform'} <ArrowRight /></Link></Button>
      </div>
    </Container>
    <Container className="relative pb-[max(1.75rem,env(safe-area-inset-bottom))]">
      <div className="flex items-end justify-between gap-4 pt-5 text-xs text-cover-muted">
        <a href="#konten-hero-lanjut" className="group inline-flex min-h-11 items-center gap-3 transition-colors hover:text-cover-foreground"><ArrowDown className="hero-cue size-4" aria-hidden="true" /><span>Visibilitas. Inteligensi. Eksekusi.</span></a>
        <span className="hidden text-[10px] sm:inline">Visualisasi industri</span>
      </div>
    </Container>
    <span id="konten-hero-lanjut" className="absolute bottom-0" aria-hidden="true" />
  </section>;
}
