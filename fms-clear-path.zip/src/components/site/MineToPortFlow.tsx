import { ArrowDown, ArrowRight, ClipboardCheck, Mountain, Ship, Truck } from 'lucide-react';
import landscape from '@/assets/mine-to-port-flow.jpg';
import { Container, GhostButton, Reveal, SectionHeading } from './ui';

const STAGES = [
  {
    title: 'Tambang', icon: Mountain,
    activity: 'Muatan siap. Armada ditugaskan.',
    body: 'Kesiapan unit, penugasan, dan keberangkatan menjadi awal catatan perjalanan yang terhubung.',
    next: 'Koordinator meninjau kesiapan sebelum unit berangkat.',
  },
  {
    title: 'Perjalanan', icon: Truck,
    activity: 'Pergerakan terlihat dalam konteks pekerjaan.',
    body: 'Posisi dan status perjalanan dikaitkan dengan penugasan, sehingga jeda atau penyimpangan dapat ditelusuri.',
    next: 'Dispatcher memeriksa kendala dan mengoordinasikan tindak lanjut.',
  },
  {
    title: 'Pelabuhan', icon: Ship,
    activity: 'Kedatangan terhubung dengan penerimaan.',
    body: 'Catatan kedatangan dan bukti penerimaan melengkapi alur dari titik asal hingga tujuan.',
    next: 'Tim penerima mengonfirmasi hasil dan menindaklanjuti selisih.',
  },
];

/** An explanatory scenario, deliberately separate from live telemetry and AI output. */
export function MineToPortFlow() {
  return (
    <section id="tambang-pelabuhan" className="section" aria-labelledby="mine-port-title">
      <Container>
        <SectionHeading eyebrow="Dari hulu ke hilir" title="Satu perjalanan. Kendali yang terhubung." lead="Dari tambang hingga pelabuhan, OPERTRACE menghubungkan armada dengan aktivitasnya—dan setiap temuan dengan tindak lanjut." />
        <h2 id="mine-port-title" className="sr-only">Alur operasional tambang hingga pelabuhan</h2>
        <Reveal className="mt-10 md:mt-14">
          <figure>
            <img src={landscape} alt="Ilustrasi tambang, jalan angkut dengan armada, dan terminal pelabuhan dalam satu bentang pesisir Indonesia" width={1920} height={1024} loading="lazy" className="aspect-[15/8] w-full rounded-md object-cover" />
            <figcaption className="mt-3 text-sm leading-relaxed text-muted-foreground">Ilustrasi alur operasional; bukan lokasi pelanggan atau pemantauan langsung.</figcaption>
          </figure>
          <ol className="mt-10 grid gap-10 md:grid-cols-3 md:gap-8">
            {STAGES.map((stage, index) => (
              <li key={stage.title} className="min-w-0">
                <div className="flex items-center gap-3">
                  <span className="flex size-10 shrink-0 items-center justify-center rounded-full bg-secondary text-foreground"><stage.icon className="size-5" aria-hidden="true" /></span>
                  <h3 className="text-title text-foreground">{stage.title}</h3>
                  {index < 2 && <ArrowRight className="ml-auto hidden size-5 shrink-0 text-brand-text md:block" aria-hidden="true" />}
                </div>
                <p className="mt-5 text-lg font-medium leading-relaxed text-foreground">{stage.activity}</p>
                <p className="mt-3 text-base leading-7 text-muted-foreground">{stage.body}</p>
                <div className="mt-5 flex items-start gap-2 text-sm leading-6 text-foreground"><ClipboardCheck className="mt-1 size-4 shrink-0 text-brand-text" aria-hidden="true" /><p>{stage.next}</p></div>
                {index < 2 && <ArrowDown className="mx-auto mt-8 size-5 text-brand-text md:hidden" aria-hidden="true" />}
              </li>
            ))}
          </ol>
          <div className="mt-12 flex flex-col gap-6 md:mt-16 md:flex-row md:items-center md:justify-between">
            <p className="max-w-xl text-base leading-7 text-muted-foreground"><strong className="font-medium text-foreground">Kendali tidak berhenti saat armada tiba.</strong> Setiap kendala perlu penanggung jawab, tindakan, dan bukti penyelesaian—agar perjalanan berikutnya berangkat dari pembelajaran yang tercatat.</p>
            <GhostButton to="/fleet-guide">Lihat panduan penerapan <ArrowRight className="size-4" /></GhostButton>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}