import { useEffect, useState } from 'react';
import { Link, useRouterState } from '@tanstack/react-router';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

/** Thumb-zone call to action on small screens; appears after the first scroll. */
export function MobileCtaBar() {
  const path = useRouterState({ select: s => s.location.pathname });
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 320);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  if (path === '/demo') return null;
  return <div className={`fixed inset-x-0 bottom-0 z-40 bg-background/90 px-4 pt-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur-xl transition-all duration-300 lg:hidden ${visible ? 'translate-y-0 opacity-100' : 'pointer-events-none translate-y-full opacity-0'}`} aria-hidden={!visible}>
    <div className="mx-auto flex max-w-lg gap-2">
      {path !== '/fleet-planner' && <Button asChild variant="outline" className="min-h-12 flex-1 rounded-md" tabIndex={visible ? 0 : -1}><Link to="/fleet-planner"><Sparkles />Alur AI</Link></Button>}
      <Button asChild className="min-h-12 flex-[1.4] rounded-md" tabIndex={visible ? 0 : -1}><Link to="/demo">Minta Demo <ArrowRight /></Link></Button>
    </div>
  </div>;
}
