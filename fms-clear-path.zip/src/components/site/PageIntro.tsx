import { useId, type ReactNode } from 'react';
import { Link } from '@tanstack/react-router';
import { ChevronRight } from 'lucide-react';
import { Container } from './ui';
import { HorizonMotion } from './HorizonMotion';

/**
 * Shared opening for every inner page, echoing the Home horizon: page-specific photo,
 * deep veil, decorative light routes, then one title and one short lead.
 */
export function PageIntro({ eyebrow, title, children, image, alt = '' }: { eyebrow: string; title: ReactNode; children?: ReactNode; image?: string; alt?: string }) {
  const id = useId();
  return <section className="cover-intro" aria-labelledby={id}>
    {image && <img src={image} alt={alt} width={1920} height={832} fetchPriority="high" />}
    <HorizonMotion compact />
    <Container className="cover-intro-inner">
      <nav aria-label="Lokasi halaman" className="mb-8 flex flex-wrap items-center gap-2 text-base text-cover-muted">
        <Link to="/" className="inline-flex min-h-11 items-center transition-colors hover:text-cover-foreground">Beranda</Link>
        <ChevronRight className="size-3.5" aria-hidden="true" />
        <span className="text-cover-foreground">{eyebrow}</span>
      </nav>
      <p className="hero-rise type-label text-cover-muted">{eyebrow}</p>
      <h1 id={id} className="hero-rise text-display mt-5 max-w-4xl text-balance text-cover-foreground" style={{ animationDelay: '120ms' }}>{title}</h1>
      {children && <div className="hero-rise type-body mt-6 max-w-2xl text-cover-muted" style={{ animationDelay: '260ms' }}>{children}</div>}
    </Container>
  </section>;
}
