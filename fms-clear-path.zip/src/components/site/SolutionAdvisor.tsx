import { useState, type FormEvent } from 'react';
import { Link } from '@tanstack/react-router';
import { useServerFn } from '@tanstack/react-start';
import { ArrowRight, CheckCircle2, CircleHelp, LoaderCircle, ShieldAlert, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { recommendSolutions } from '@/lib/recommendations.functions';
import { challengeSchema, type Recommendation } from '@/lib/recommendation-schema';

export function SolutionAdvisor() {
  const recommend = useServerFn(recommendSolutions);
  const [industry, setIndustry] = useState('');
  const [challenge, setChallenge] = useState('');
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState<Recommendation | null>(null);
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (pending) return;
    const input = challengeSchema.safeParse({ industry, challenge });
    if (!input.success) { setError(input.error.issues[0]?.message ?? 'Lengkapi formulir.'); return; }
    setError(''); setResult(null); setPending(true);
    try {
      const response = await recommend({ data: input.data });
      setResult(response.result); setError(response.error ?? '');
    } catch { setError('Koneksi terputus. Isian Anda tidak hilang; silakan coba kembali nanti.'); }
    finally { setPending(false); }
  }
  return <div className="grid items-start gap-10 lg:grid-cols-[1fr_1.15fr]">
    <form onSubmit={submit} className="space-y-6">
      <div><label htmlFor="advisor-industry" className="mb-2 block font-medium">Industri Anda</label><Input id="advisor-industry" value={industry} onChange={e => setIndustry(e.target.value)} required minLength={2} maxLength={100} placeholder="Contoh: pertambangan, logistik, konstruksi" className="min-h-12 bg-card text-base" /></div>
      <div><label htmlFor="advisor-challenge" className="mb-2 block font-medium">Tantangan operasional</label><Textarea id="advisor-challenge" value={challenge} onChange={e => setChallenge(e.target.value)} required minLength={20} maxLength={4000} rows={7} placeholder="Apa yang terjadi di lapangan, dampaknya, skala armada atau aset, dan hasil yang ingin Anda capai?" className="bg-card text-base" /><p className="mt-2 text-sm text-muted-foreground">Jangan sertakan kata sandi, data pribadi, atau informasi rahasia perusahaan.</p></div>
      <Button type="submit" disabled={pending} className="min-h-12 w-full sm:w-auto">{pending ? <LoaderCircle className="animate-spin" /> : <Sparkles />} {pending ? 'Menganalisis tantangan…' : 'Temukan solusi OPERTRACE'}</Button>
      {error && <p role="alert" className="flex gap-2 text-destructive"><ShieldAlert className="size-5 shrink-0" />{error}</p>}
    </form>
    <div aria-live="polite" aria-busy={pending} className="min-w-0 pt-6 lg:pl-12 lg:pt-0">
      {pending ? <p role="status" className="flex items-center gap-2 text-muted-foreground"><LoaderCircle className="size-5 animate-spin" />Mencocokkan kebutuhan dengan katalog OPERTRACE…</p> : result ? <div className="space-y-6">
        <div className="inline-flex items-center gap-2 rounded-md bg-status-info-bg px-3 py-2 text-sm font-medium text-status-info"><CircleHelp className="size-4" />Rekomendasi awal · Perlu validasi</div>
        <h3 className="text-title">Solusi yang relevan</h3><p className="critical-data rounded-md p-4 leading-relaxed">{result.summary}</p>
        {result.solutions.map((s) => <article key={s.domain} className="pb-6"><h4 className="mt-1 font-semibold">{s.domain}</h4><p className="mt-3 leading-relaxed text-muted-foreground">{s.reason}</p><p className="mt-3 flex gap-2 leading-relaxed"><CheckCircle2 className="mt-1 size-4 shrink-0 text-status-success" />{s.nextStep}</p><Link to="/platform" className="mt-3 inline-flex items-center gap-2 text-brand-text underline underline-offset-4">Lihat domain platform <ArrowRight className="size-4" /></Link></article>)}
        {result.questions.length > 0 && <div><h4 className="font-semibold">Untuk diskusi berikutnya</h4><ul className="mt-3 list-disc space-y-2 pl-5 text-muted-foreground">{result.questions.map(q => <li key={q}>{q}</li>)}</ul></div>}
        <p className="flex gap-2 rounded-md bg-status-warning-bg p-4 text-sm leading-relaxed text-status-warning"><ShieldAlert className="mt-1 size-5 shrink-0" />{result.caution}</p>
      </div> : <div><p className="eyebrow">OPERTRACE · Solution Advisor</p><h3 className="text-title mt-4">Mulai dari tantangan nyata.</h3><p className="mt-4 leading-relaxed text-muted-foreground">Armada yang sulit dipantau. Downtime yang berulang. Persediaan yang tidak cocok. Ceritakan kondisi operasi Anda.</p><div className="mt-8 space-y-4 pt-6">{['SEE — Visibilitas operasi', 'UNDERSTAND — Analisis berbasis bukti', 'ACT — Eksekusi yang akuntabel'].map(label => <p key={label} className="flex gap-3"><CheckCircle2 className="size-5 text-brand-text" />{label}</p>)}</div></div>}
    </div>
  </div>;
}