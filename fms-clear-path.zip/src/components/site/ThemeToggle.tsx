import { useEffect, useState } from 'react';
import { Moon, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function ThemeToggle() {
  const [dark, setDark] = useState(true);
  useEffect(() => {
    let saved: string | null = null;
    try { saved = localStorage.getItem('opertrace-theme'); } catch { /* Storage may be blocked in embedded browsers. */ }
    const next = saved === 'dark' || (saved !== 'light' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    document.documentElement.classList.toggle('dark', next);
    setDark(next);
  }, []);
  function toggle() {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle('dark', next);
    try { localStorage.setItem('opertrace-theme', next ? 'dark' : 'light'); } catch { /* Keep switching usable without persistence. */ }
  }
  return <Button variant="ghost" size="icon" onClick={toggle} aria-label={dark ? 'Aktifkan mode terang' : 'Aktifkan mode gelap'} title={dark ? 'Mode terang' : 'Mode gelap'} className="min-h-11 min-w-11">{dark ? <Sun /> : <Moon />}</Button>;
}