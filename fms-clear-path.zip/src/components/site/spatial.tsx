import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { useTilt } from "@/hooks/use-tilt";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Container, Reveal } from "./ui";
import { HorizonMotion } from "./HorizonMotion";

/*
 * Spatial composition shared by every page, derived from the Horizon Nusantara home:
 *  - 2D planes (majority): flat editorial headings, spacious rows, quiet lists.
 *  - 3D depth (secondary): pointer-reactive cards and image frames, one group per page.
 *  - 5D orbit (accent): time-based light routes in openings, closing bands and step rails.
 */

/* ————— 2D planes ————— */

/** Editorial heading: title on the left, a single short lead on the right. */
export function PlaneHeading({ eyebrow, title, lead, id }: { eyebrow: string; title: ReactNode; lead?: ReactNode; id?: string }) {
  return (
    <Reveal className="plane-heading">
      <div>
        <p className="eyebrow">{eyebrow}</p>
        <h2 id={id} className="text-headline mt-5 text-balance text-foreground">{title}</h2>
      </div>
      {lead && <p className="text-lead">{lead}</p>}
    </Reveal>
  );
}

export type PlaneItem = { title: ReactNode; body?: ReactNode; meta?: ReactNode };

/** Unnumbered editorial rows; spacing alone separates items. */
export function PlaneRows({ items, columns = 1, label }: { items: PlaneItem[]; columns?: 1 | 2; label?: string }) {
  return (
    <ul aria-label={label} className={cn("plane-rows", columns === 2 && "plane-rows-2")}>
      {items.map((item, i) => (
        <li key={i}>
          <Reveal delay={Math.min(i, 4) * 60} className="plane-row">
            <div className="min-w-0">
              <h3 className="plane-title">{item.title}</h3>
              {item.meta && <p className="mt-3 type-body text-brand-text">{item.meta}</p>}
              {item.body && <p className="plane-body">{item.body}</p>}
            </div>
          </Reveal>
        </li>
      ))}
    </ul>
  );
}

/** Quiet inline list for names and categories: no pills, no borders. */
export function PlaneList({ items, label, center = false }: { items: string[]; label?: string; center?: boolean }) {
  return (
    <ul aria-label={label} className={cn("plane-list", center && "justify-center")}>
      {items.map((item) => <li key={item}>{item}</li>)}
    </ul>
  );
}

/* ————— 3D depth ————— */

export function DepthCard({ children, className }: { children: ReactNode; className?: string }) {
  const ref = useTilt<HTMLDivElement>(7);
  return <div ref={ref} className={cn("depth-card", className)}>{children}</div>;
}

export function DepthGlyph({ children }: { children: ReactNode }) {
  return <span className="depth-glyph" aria-hidden="true">{children}</span>;
}

export function DepthFrame({ src, alt, className, width = 1280, height = 896 }: { src: string; alt: string; className?: string; width?: number; height?: number }) {
  const ref = useTilt<HTMLDivElement>(5);
  return (
    <div ref={ref} className={cn("depth-frame", className)}>
      <img src={src} alt={alt} width={width} height={height} loading="lazy" />
    </div>
  );
}

/* ————— 5D orbit (time + interaction) ————— */

export type OrbitStep = { title: ReactNode; body?: ReactNode; meta?: ReactNode; note?: ReactNode; icon?: ReactNode };

/** Steps strung on a light rail with a travelling pulse; horizontal on wide screens when axis="x". */
export function OrbitSteps({ steps, axis = "y", label }: { steps: OrbitStep[]; axis?: "x" | "y"; label?: string }) {
  return (
    <ol aria-label={label} className="orbit-steps" data-axis={axis} style={{ ["--orbit-count" as string]: steps.length }}>
      {steps.map((s, i) => (
        <li key={i} className="orbit-step">
          <span className="orbit-node" aria-hidden="true">{s.icon ?? <ArrowRight className="size-5" />}</span>
          <Reveal delay={Math.min(i, 4) * 70} className="min-w-0">
            {s.meta && <p className="type-label text-brand-text">{s.meta}</p>}
            <h3 className="plane-title mt-2">{s.title}</h3>
            {s.body && <p className="plane-body">{s.body}</p>}
            {s.note && <p className="mt-5 type-body text-foreground">{s.note}</p>}
          </Reveal>
        </li>
      ))}
    </ol>
  );
}

type CtaLink = { to: string; label: string };

/** Closing band that echoes the Home opening: dark horizon, light routes, one decision. */
export function HorizonCta({ eyebrow, title, body, primary, secondary }: { eyebrow: string; title: ReactNode; body?: ReactNode; primary: CtaLink; secondary?: CtaLink }) {
  return (
    <section className="horizon-cta" aria-label={eyebrow}>
      <Container>
        <Reveal>
          <div className="horizon-cta-inner">
            <HorizonMotion compact />
            <p className="type-label text-cover-muted">{eyebrow}</p>
            <h2 className="text-display mx-auto mt-6 max-w-3xl text-balance text-cover-foreground">{title}</h2>
            {body && <p className="type-body mx-auto mt-6 max-w-xl text-cover-muted">{body}</p>}
            <div className="mx-auto mt-10 flex max-w-sm flex-col items-stretch gap-3 sm:max-w-none sm:flex-row sm:justify-center">
              <Button asChild size="lg" className="h-12 rounded-full px-7 transition-all duration-300 hover:-translate-y-0.5 active:scale-[0.98]"><Link to={primary.to}>{primary.label} <ArrowRight /></Link></Button>
              {secondary && <Button asChild variant="outline" size="lg" className="cover-outline h-12 rounded-full px-7 transition-all duration-300 hover:-translate-y-0.5 active:scale-[0.98]"><Link to={secondary.to}>{secondary.label}</Link></Button>}
            </div>
          </div>
        </Reveal>
      </Container>
    </section>
  );
}
