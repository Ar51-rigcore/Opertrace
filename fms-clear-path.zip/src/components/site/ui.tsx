import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { useReveal } from "@/hooks/use-reveal";
import logoLight from "@/assets/opertrace-full-logo-light.png";
import logoDark from "@/assets/opertrace-full-logo-dark.png";
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

/* ————— Layout primitives (semantic + shared spacing metrics) ————— */

export function Container({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`mx-auto w-full min-w-0 max-w-[1280px] px-6 md:px-10 ${className}`}>{children}</div>;
}

/* Scroll-reveal wrapper: fades/slides content in once on viewport entry. */
export function Reveal({
  children,
  className = "",
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useReveal<HTMLDivElement>();
  return (
    <div
      ref={ref}
      data-visible="false"
      style={delay ? { transitionDelay: `${delay}ms` } : undefined}
      className={`reveal ${className}`}
    >
      {children}
    </div>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  lead,
  align = "left",
}: {
  eyebrow: string;
  title: string;
  lead?: string;
  align?: "left" | "center";
}) {
  return (
    <Reveal className={align === "center" ? "flex flex-col items-center text-center" : ""}>
      <p className="eyebrow">{eyebrow}</p>
      <h2 className="text-headline mt-4 max-w-2xl text-balance text-foreground">
        {align === "center" ? <span className="mx-auto block max-w-2xl">{title}</span> : title}
      </h2>
      {lead && (
        <p className={`text-lead mt-5 max-w-xl ${align === "center" ? "mx-auto" : ""}`}>{lead}</p>
      )}
    </Reveal>
  );
}

/* ————— Buttons (micro-consistent radius, motion, 10% accent) ————— */

export function PrimaryButton({ to, children }: { to: string; children: ReactNode }) {
  return (
    <Button asChild size="lg" className="h-auto min-h-12 w-full rounded-md px-6 py-3.5 transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98] sm:w-auto">
    <Link
      to={to}
    >
      {children}
    </Link>
    </Button>
  );
}

export function GhostButton({ to, children }: { to: string; children: ReactNode }) {
  return (
    <Button asChild variant="outline" size="lg" className="group h-auto min-h-12 w-full rounded-md px-6 py-3.5 transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98] sm:w-auto">
    <Link
      to={to}
    >
      {children}
    </Link>
    </Button>
  );
}

/* Editorial content is unframed; only genuinely framed interactive tools use surfaces. */
export function FeatureCard({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={cn("editorial-feature h-full py-6 md:py-8", className)}>{children}</div>;
}

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link
      to="/"
      aria-label="OPERTRACE — kembali ke beranda"
      className="brand-logo inline-flex shrink-0 items-center rounded-sm transition-opacity duration-300 hover:opacity-80"
    >
      <img src={logoLight} alt="Opertrace" width={1768} height={370} className="logo-on-light h-auto w-full object-contain dark:hidden" />
      <img src={logoDark} alt="Opertrace" width={1768} height={370} className="logo-on-dark hidden h-auto w-full object-contain dark:block" />
      {!compact && <span className="sr-only">oleh PT Cakrakarsa Aditama Nusantara</span>}
    </Link>
  );
}
