export const COMPANY_CONTACT = {
  address: 'Jl. Mekarwangi Kav. Villa Mutiara, Bogor, Jawa Barat, Indonesia 16161',
  phone: '0881010089399',
  phoneHref: 'tel:+62881010089399',
  emails: [
    { label: 'Informasi umum', value: 'info@opertrace.co.id' },
    { label: 'Customer care', value: 'customercare@opertrace.co.id' },
  ],
  website: 'www.opertrace.co.id',
  websiteHref: 'https://www.opertrace.co.id',
  demoNotificationEmail: 'demo@operion.id',
} as const;
