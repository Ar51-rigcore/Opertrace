import { z } from 'zod';

export const demoRequestSchema = z.object({
  name: z.string().trim().min(2, 'Nama minimal 2 karakter.').max(100, 'Nama maksimal 100 karakter.'),
  email: z.string().trim().toLowerCase().email('Alamat email tidak valid.').max(255, 'Email maksimal 255 karakter.'),
  fleetNeeds: z.string().trim().min(20, 'Jelaskan kebutuhan armada setidaknya 20 karakter.').max(4000, 'Maksimal 4.000 karakter.'),
  // Honeypot: real visitors never see or fill this field.
  website: z.string().max(0).optional().default(''),
});
export type DemoRequestInput = z.infer<typeof demoRequestSchema>;
