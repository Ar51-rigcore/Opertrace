import { createServerFn } from '@tanstack/react-start';
import { createClient } from '@supabase/supabase-js';
import type { Database } from '@/integrations/supabase/types';
import { demoRequestSchema } from './demo-request-schema';

// Public insert-only endpoint: the table allows anonymous INSERT and nothing else.
export const submitDemoRequest = createServerFn({ method: 'POST' })
  .inputValidator((input: unknown) => demoRequestSchema.parse(input))
  .handler(async ({ data }) => {
    if (data.website) return { ok: true as const, error: null };
    const url = process.env['SUPABASE_URL'];
    const key = process.env['SUPABASE_PUBLISHABLE_KEY'];
    if (!url || !key) return { ok: false as const, error: 'Formulir belum dapat menerima permintaan. Silakan coba kembali nanti.' };
    const client = createClient<Database>(url, key, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: { fetch: (input, init) => {
        const headers = new Headers(init?.headers);
        if (key.startsWith('sb_') && headers.get('Authorization') === `Bearer ${key}`) headers.delete('Authorization');
        headers.set('apikey', key);
        return fetch(input, { ...init, headers });
      } },
    });
    const { error } = await client.from('demo_requests').insert({ name: data.name, email: data.email, fleet_needs: data.fleetNeeds });
    if (error) {
      console.error('Demo request insert failed', { code: error.code });
      return { ok: false as const, error: 'Permintaan belum terkirim. Isian Anda tetap ada; silakan coba kembali.' };
    }
    return { ok: true as const, error: null };
  });
