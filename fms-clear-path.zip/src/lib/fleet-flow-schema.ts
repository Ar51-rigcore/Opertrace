import { z } from 'zod';

export const FLEET_PHASES = ['SEE', 'UNDERSTAND', 'ACT'] as const;

export const fleetNeedsSchema = z.object({
  industry: z.string().trim().min(2, 'Isi industri Anda.').max(100),
  fleetSize: z.string().trim().max(120).default(''),
  needs: z.string().trim().min(20, 'Jelaskan kebutuhan armada setidaknya 20 karakter.').max(4000, 'Maksimal 4.000 karakter.'),
});
export type FleetNeeds = z.infer<typeof fleetNeedsSchema>;

export const fleetFlowSchema = z.object({
  summary: z.string().min(1),
  stages: z.array(z.object({
    phase: z.enum(FLEET_PHASES),
    title: z.string().min(1),
    action: z.string().min(1),
    domain: z.string().min(1),
    metric: z.string().min(1),
  })).max(6),
  questions: z.array(z.string()).max(3),
  caution: z.string(),
});
export type FleetFlow = z.infer<typeof fleetFlowSchema>;

/** Rejects any flow that names a domain outside the OPERTRACE catalog. */
export function hasOnlyKnownDomains(flow: FleetFlow, known: string[]) {
  return flow.stages.every(stage => known.includes(stage.domain));
}
