/** Stop at the provider's terminal event, not at a possibly delayed socket close. */
export async function collectFleetFlowText(events: AsyncIterable<{ type: string; delta?: unknown }>) {
  let text = '';
  for await (const event of events) {
    if (event.type === 'response.output_text.delta' && typeof event.delta === 'string') text += event.delta;
    if (event.type === 'response.completed') return { text, completed: true };
    if (event.type === 'response.incomplete' || event.type === 'response.failed' || event.type === 'error') {
      return { text, completed: false };
    }
  }
  return { text, completed: false };
}