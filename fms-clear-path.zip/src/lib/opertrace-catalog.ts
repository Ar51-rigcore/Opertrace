export const DOMAIN_GROUPS: { group: string; domains: { name: string; desc: string }[] }[] = [
  {
    group: "A. Enterprise & Asset Foundation",
    domains: [
      { name: "Identity, Organization & Trust", desc: "Identitas pengguna, organisasi, keanggotaan, verifikasi, dan kewenangan." },
      { name: "Asset Digital Passport & Ownership", desc: "Identitas, kepemilikan, kondisi, dokumentasi, dan siklus hidup aset." },
    ],
  },
  {
    group: "B. Asset Commerce & Procurement",
    domains: [
      { name: "Marketplace Asset Sell/Buy", desc: "Ekosistem jual beli aset dan peralatan industri." },
      { name: "Smart Rental Orchestration", desc: "Ketersediaan, reservasi, rental, mobilisasi, dan pengembalian alat." },
      { name: "Procurement & Tender", desc: "Pengadaan, RFQ, penawaran, evaluasi, dan persetujuan." },
      { name: "Projects & Industrial Planning", desc: "Proyek, pekerjaan, anggaran, jadwal, dan progres." },
    ],
  },
  {
    group: "C. Fleet & Physical Operations",
    domains: [
      { name: "Fleet Live & Dispatch", desc: "Armada, GPS/telematika, penugasan, perjalanan, dan status operasional." },
      { name: "Maintenance, Workshop & Parts", desc: "Inspeksi, perawatan, work order, workshop, suku cadang, dan downtime." },
      { name: "Mining Production & HSE", desc: "Produksi pertambangan, keselamatan, dan bukti operasional." },
      { name: "Hauling & Inland Logistics", desc: "Perjalanan hauling, rute, timbangan, pengiriman, dan biaya transportasi." },
    ],
  },
  {
    group: "D. Materials & Commodity",
    domains: [
      { name: "Materials, Stockpile & Inventory", desc: "Material, lot, stockpile, pergerakan, dan rekonsiliasi persediaan." },
      { name: "Commodity Exchange", desc: "Marketplace perdagangan komoditas industri." },
      { name: "Processing & Industrial Quality", desc: "Proses pengolahan, inspeksi kualitas, assay, dan hasil produksi." },
    ],
  },
  {
    group: "E. Commercial & Financial Operations",
    domains: [
      { name: "Contracts, Billing & Settlement", desc: "Kontrak, invoice, settlement, dan rekonsiliasi transaksi." },
      { name: "Disputes, Customer Support & Reputation", desc: "Klaim, perselisihan, dukungan pelanggan, dan reputasi." },
      { name: "Partner Network & Marketplace Services", desc: "Profil perusahaan, vendor, mitra, dan kualifikasi layanan." },
    ],
  },
  {
    group: "F. Intelligence & Platform Management",
    domains: [
      { name: "Loss Engine & Industrial Intelligence", desc: "Analisis kehilangan nilai, produktivitas, performa, dan indikator bisnis." },
      { name: "Pricing, Subscription & Organization Billing", desc: "Paket, langganan, hak penggunaan, dan tagihan platform." },
      { name: "Communication & Notification", desc: "Komunikasi, pesan, notifikasi, dan preferensi pengguna." },
      { name: "Audit, Compliance & Platform Administration", desc: "Audit, administrasi, kebijakan, dan kepatuhan." },
      { name: "Industrial Network, Hybrid Community & Collaboration", desc: "Jaringan profesional, komunitas, koneksi bisnis, dan kolaborasi industri." },
      { name: "Industrial Pricing & Quotation Engine", desc: "Struktur harga, quotation, komponen biaya, dan penawaran komersial." },
      { name: "Commodity–Equipment–Fleet Matching", desc: "Pencocokan komoditas dengan alat, kapasitas, armada, dan persyaratan keselamatan." },
      { name: "Maritime Shipping, Port Logistics & EXIM", desc: "Pengiriman laut, kapal, pelabuhan, kontainer, freight, ekspor, dan impor." },
    ],
  },
];

