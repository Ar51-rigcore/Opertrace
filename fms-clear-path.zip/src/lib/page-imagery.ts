import about from '@/assets/page-about.jpg';
import vision from '@/assets/page-vision.jpg';
import technology from '@/assets/page-technology.jpg';
import team from '@/assets/page-team.jpg';
import contact from '@/assets/page-contact.jpg';
import demo from '@/assets/page-demo.jpg';
import planner from '@/assets/page-planner.jpg';
import guide from '@/assets/indonesia-fleet-installation.jpg';
import mining from '@/assets/ind-mining.jpg';
import construction from '@/assets/ind-construction.jpg';
import plantation from '@/assets/ind-plantation.jpg';
import energy from '@/assets/ind-energy.jpg';
import logistics from '@/assets/ind-logistics.jpg';
import manufacturing from '@/assets/ind-manufacturing.jpg';

export const PAGE_IMAGERY = {
  about: { image: about, alt: 'Ilustrasi praktisi industri Indonesia berdiskusi di lokasi tambang' },
  vision: { image: vision, alt: 'Visualisasi armada logistik melintasi bentang alam Nusantara' },
  technology: { image: technology, alt: 'Visualisasi perangkat telematika di kabin unit pertambangan' },
  team: { image: team, alt: 'Ilustrasi kolaborasi profesional Indonesia, bukan foto staf perusahaan' },
  contact: { image: contact, alt: 'Ilustrasi ruang pertemuan bisnis dengan suasana tropis Indonesia' },
  demo: { image: demo, alt: 'Visualisasi pusat kendali operasi dan pergerakan armada' },
  planner: { image: planner, alt: 'Visualisasi penataan armada dan alur perjalanan di depot logistik' },
  guide: { image: guide, alt: 'Ilustrasi teknisi dan pengelola armada Indonesia memasang telematika dan belajar menggunakan tablet' },
};

export const INDUSTRY_IMAGERY = [
  { image: mining, alt: 'Visualisasi haul truck pada operasi pertambangan' },
  { image: construction, alt: 'Visualisasi peralatan dan proyek konstruksi' },
  { image: plantation, alt: 'Visualisasi armada pengangkutan di perkebunan' },
  { image: energy, alt: 'Visualisasi infrastruktur dan aset sektor energi' },
  { image: logistics, alt: 'Visualisasi pelabuhan, kapal, dan rantai pasok logistik' },
  { image: manufacturing, alt: 'Visualisasi fasilitas manufaktur dan pengolahan industri' },
];