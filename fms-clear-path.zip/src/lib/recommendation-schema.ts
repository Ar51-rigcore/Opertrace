import { z } from 'zod';

export const challengeSchema = z.object({
  industry: z.string().trim().min(2).max(100),
  challenge: z.string().trim().min(20, 'Jelaskan tantangan setidaknya 20 karakter.').max(4000),
});

export const recommendationSchema = z.object({
  summary: z.string().min(1),
  solutions: z.array(z.object({ domain: z.string(), reason: z.string(), nextStep: z.string() })).max(3),
  questions: z.array(z.string()).max(3),
  caution: z.string(),
});
export type Recommendation = z.infer<typeof recommendationSchema>;