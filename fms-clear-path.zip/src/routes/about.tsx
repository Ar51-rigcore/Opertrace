import { PlaneHeading, PlaneRows, PlaneList, DepthFrame, HorizonCta } from '@/components/site/spatial';
import { PAGE_IMAGERY } from '@/lib/page-imagery';
import { PageIntro } from "@/components/site/PageIntro";
import { createFileRoute } from "@tanstack/react-router";
import { Container } from "@/components/site/ui";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "Tentang Kami — PT Cakrakarsa Aditama Nusantara" },
      {
        name: "description",
        content:
          "PT Cakrakarsa Aditama Nusantara membangun solusi teknologi dan ekosistem bisnis untuk industri: We Build Solutions. We Connect Opportunities. We Create Value.",
      },
      { property: "og:title", content: "Tentang Kami — PT Cakrakarsa Aditama Nusantara" },
      {
        property: "og:description",
        content: "We Build Solutions. We Connect Opportunities. We Create Value.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: About,
});

const ORIENTATIONS = [
  {
    title: "Technology Innovation",
    body: "Mendorong pemanfaatan teknologi untuk menjawab kebutuhan bisnis dan industri yang terus berkembang.",
  },
  {
    title: "Industrial Connectivity",
    body: "Menghubungkan perusahaan, aset, sumber daya, informasi, dan peluang dalam ekosistem yang lebih terintegrasi.",
  },
  {
    title: "Sustainable Business Growth",
    body: "Membangun nilai bisnis melalui investasi strategis, kolaborasi, dan pertumbuhan yang berkelanjutan.",
  },
];

const WHAT_WE_DO = [
  "Pengembangan platform digital dan aplikasi bisnis.",
  "Sistem manajemen armada dan aset industri.",
  "Integrasi teknologi dan informasi operasional.",
  "Industrial marketplace dan business networking.",
  "Data analytics dan business intelligence.",
  "Solusi pengelolaan proyek dan operasional.",
  "Pengembangan ekosistem bisnis dan kemitraan strategis.",
  "Implementasi dan dukungan solusi teknologi perusahaan.",
];

const APPROACH = [
  {
    title: "Understand",
    body: "Memahami kebutuhan, tantangan, dan karakteristik bisnis setiap mitra.",
  },
  {
    title: "Integrate",
    body: "Menghubungkan teknologi, proses, data, dan sumber daya yang relevan.",
  },
  {
    title: "Innovate",
    body: "Mengembangkan solusi yang memberikan nilai tambah dan relevan dengan kebutuhan pengguna.",
  },
  {
    title: "Grow",
    body: "Membangun hubungan jangka panjang dan pertumbuhan bersama para pemangku kepentingan.",
  },
];

function About() {
  return <>
    <PageIntro {...PAGE_IMAGERY.about} eyebrow="Tentang Kami" title="Menghubungkan teknologi dengan kenyataan industri.">PT Cakrakarsa Aditama Nusantara mengembangkan solusi teknologi dan ekosistem bisnis untuk kebutuhan operasi fisik di Indonesia.</PageIntro>
    <section className="section"><Container>
      <PlaneHeading eyebrow="Arah kami" title="Nilai dibangun dari pemahaman lapangan." lead="OPERTRACE menghubungkan kebutuhan operasional dan komersial, dengan perhatian pada proses, sumber daya, dan keputusan manusia." />
      <div className="editorial-composition"><DepthFrame src={PAGE_IMAGERY.about.image} alt={PAGE_IMAGERY.about.alt} /><PlaneRows items={ORIENTATIONS} /></div>
    </Container></section>
    <section className="section"><Container>
      <PlaneHeading eyebrow="Yang kami kerjakan" title="Tantangan bisnis menjadi titik awal solusi." />
      <PlaneList items={WHAT_WE_DO} />
    </Container></section>
    <section className="section"><Container>
      <PlaneHeading eyebrow="Cara kami bekerja" title="Memahami sebelum membangun." lead="Pendekatan yang menghubungkan kebutuhan mitra dengan teknologi, proses, dan kesempatan bertumbuh bersama." />
      <PlaneRows columns={2} items={APPROACH} />
    </Container></section>
    <HorizonCta eyebrow="Kemitraan" title="Bangun arah berikutnya bersama." primary={{to:'/contact',label:'Diskusikan kemitraan'}} secondary={{to:'/platform',label:'Jelajahi OPERTRACE'}} />
  </>;
}
