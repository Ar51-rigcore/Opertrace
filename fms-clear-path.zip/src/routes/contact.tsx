import { PlaneHeading, HorizonCta } from '@/components/site/spatial';
import { PAGE_IMAGERY } from '@/lib/page-imagery';
import { createFileRoute, Link } from '@tanstack/react-router';
import { Container } from '@/components/site/ui';
import { SolutionAdvisor } from '@/components/site/SolutionAdvisor';
import { pageMeta } from '@/lib/page-meta';
import { PageIntro } from '@/components/site/PageIntro';
import { Globe, Mail, MapPin, Phone } from 'lucide-react';
import { COMPANY_CONTACT } from '@/lib/company-contact';

export const Route = createFileRoute('/contact')({
  head: () => pageMeta('Kontak & Rekomendasi Solusi — OPERTRACE', 'Jelaskan tantangan operasional Anda dan temukan domain OPERTRACE yang relevan melalui rekomendasi AI berbasis katalog situs.'),
  component: Contact,
});
function Contact() {
  const c = COMPANY_CONTACT;
  return <>
    <PageIntro {...PAGE_IMAGERY.contact} eyebrow="Kontak & Kemitraan" title="Percakapan yang berangkat dari operasi Anda.">Ceritakan kebutuhan armada, pekerjaan lapangan, atau alur bisnis yang ingin Anda hubungkan.</PageIntro>
    <section className="section contact-editorial"><Container>
      <PlaneHeading eyebrow="Kontak resmi" title="PT Cakrakarsa Aditama Nusantara" lead="Hubungi tim OPERTRACE melalui saluran resmi berikut." />
      <address className="contact-details not-italic">
        <div><MapPin aria-hidden="true" /><div><h3>Alamat</h3><p>{c.address}</p></div></div>
        <div><Phone aria-hidden="true" /><div><h3>Telepon</h3><a href={c.phoneHref}>{c.phone}</a></div></div>
        <div><Mail aria-hidden="true" /><div><h3>Email</h3>{c.emails.map(e => <a key={e.value} href={`mailto:${e.value}`}>{e.value}</a>)}</div></div>
        <div><Globe aria-hidden="true" /><div><h3>Website</h3><a href={c.websiteHref} target="_blank" rel="noopener noreferrer">{c.website}</a></div></div>
      </address>
    </Container></section>
    <section className="section contact-editorial"><Container>
      <PlaneHeading eyebrow="Rekomendasi awal" title="Temukan titik awal yang relevan." lead="Jelaskan kondisi lapangan. AI mencocokkan kebutuhan dengan katalog OPERTRACE; hasilnya perlu ditinjau bersama tim." />
      <div className="consultation-workspace"><SolutionAdvisor /></div>
      <p className="type-body mt-10 text-muted-foreground">Analisis ini tidak mengirim permintaan demo. Gunakan <Link to="/demo" className="text-brand-text underline underline-offset-4">formulir permintaan demo</Link> untuk mengajukannya.</p>
    </Container></section>
    <HorizonCta eyebrow="Percakapan berikutnya" title="Lihat platform dalam konteks Anda." primary={{to:'/demo',label:'Minta demo'}} secondary={{to:'/fleet-guide',label:'Panduan penerapan'}} />
  </>;
}
