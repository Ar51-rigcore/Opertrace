import { PlaneRows, DepthFrame } from '@/components/site/spatial';
import { PAGE_IMAGERY } from '@/lib/page-imagery';
import { createFileRoute, Link } from '@tanstack/react-router';
import { ArrowRight } from 'lucide-react';
import { Container } from '@/components/site/ui';
import { DemoRequestForm } from '@/components/site/DemoRequestForm';
import { pageMeta } from '@/lib/page-meta';
import { PageIntro } from '@/components/site/PageIntro';

export const Route = createFileRoute('/demo')({
  head: () => pageMeta('Minta Demo OPERTRACE — Fleet & Operations Platform', 'Ajukan demo OPERTRACE: kirim nama, email kerja, dan kebutuhan armada Anda untuk ditinjau tim PT Cakrakarsa Aditama Nusantara.'),
  component: DemoPage,
});

function DemoPage() {
  return <>
    <PageIntro {...PAGE_IMAGERY.demo} eyebrow="Minta Demo" title="Sebuah demo. Konteks operasi Anda.">Bagikan kebutuhan armada agar pembahasan dapat berangkat dari medan, skala, dan tantangan yang relevan.</PageIntro>
    <section className="section consultation-page"><Container className="consultation-layout">
      <div><p className="type-label text-brand-text">Yang dapat Anda tinjau</p><h2 className="text-headline mt-5">Satu alur dari lapangan ke keputusan.</h2>
        <PlaneRows items={[
          {title:'Visibilitas',body:'Posisi, status, dan perjalanan unit dalam konteks penugasan.'},
          {title:'Pemahaman',body:'Catatan aktivitas sebagai dasar meninjau jeda, antrean, dan biaya.'},
          {title:'Tindak lanjut',body:'Penugasan dan bukti pelaksanaan yang dapat ditelusuri.'}
        ]} />
        <Link to="/fleet-planner" className="type-body inline-flex min-h-12 items-center gap-3 text-brand-text">Tinjau kebutuhan dengan perencana AI <ArrowRight className="size-5 shrink-0" /></Link>
      </div>
      <div className="consultation-form"><p className="type-label text-brand-text mb-8">Permintaan demo</p><DemoRequestForm /></div>
    </Container></section>
    <section className="section pt-0"><Container><DepthFrame src={PAGE_IMAGERY.demo.image} alt={PAGE_IMAGERY.demo.alt} className="wide-depth-frame" /></Container></section>
  </>;
}
