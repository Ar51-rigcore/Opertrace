import { PlaneHeading, OrbitSteps, DepthFrame, HorizonCta } from '@/components/site/spatial';
import { PAGE_IMAGERY } from '@/lib/page-imagery';
import { createFileRoute } from '@tanstack/react-router';
import { ClipboardList, FileSignature, GraduationCap, LifeBuoy, MapPinned, Rocket, Settings2, Truck } from 'lucide-react';
import { Container } from '@/components/site/ui';
import { PageIntro } from '@/components/site/PageIntro';
import { pageMeta } from '@/lib/page-meta';

export const Route = createFileRoute('/fleet-guide')({
  head: () => pageMeta('Panduan Alur Armada OPERTRACE — Pemesanan hingga Pelatihan', 'Tahapan nyata implementasi OPERTRACE: konsultasi, survei lokasi, pemesanan, instalasi perangkat, konfigurasi, uji coba, pelatihan pengguna, dan pendampingan.'),
  component: FleetGuide,
});

const STAGES = [
  { icon: ClipboardList, title: 'Konsultasi & demo', time: 'Minggu 1', body: 'Tim OPERTRACE memetakan jenis dan jumlah unit, lokasi operasi, kendala saat ini, serta target yang ingin dicapai, lalu menampilkan demo sesuai kondisi Anda.', out: 'Ringkasan kebutuhan & domain solusi yang relevan' },
  { icon: MapPinned, title: 'Survei lokasi & unit', time: 'Minggu 1–2', body: 'Survei lapangan untuk memeriksa unit, kelistrikan, cakupan sinyal, area kerja, dan titik penting seperti pit, workshop, atau gudang.', out: 'Laporan survei & rancangan teknis' },
  { icon: FileSignature, title: 'Penawaran & pemesanan', time: 'Minggu 2', body: 'Penawaran berisi ruang lingkup, perangkat, lisensi, jadwal, dan SLA. Setelah disetujui, pesanan dikonfirmasi dan jadwal instalasi dikunci.', out: 'Kontrak / PO & jadwal implementasi' },
  { icon: Truck, title: 'Pengadaan & pengiriman perangkat', time: 'Minggu 2–4', body: 'Perangkat GPS/telematika, sensor, dan aksesori disiapkan, diuji di gudang, lalu dikirim ke lokasi sesuai jadwal.', out: 'Perangkat siap pasang per unit' },
  { icon: Settings2, title: 'Instalasi & konfigurasi', time: 'Minggu 3–5', body: 'Teknisi memasang perangkat di setiap unit dengan jadwal yang meminimalkan downtime. Platform dikonfigurasi: data unit, geofence, pengguna, peran, dan aturan peringatan.', out: 'Unit terpantau & akun pengguna aktif' },
  { icon: Rocket, title: 'Uji coba & go-live', time: 'Minggu 5–6', body: 'Uji coba terbatas untuk memastikan data akurat dan alur kerja sesuai. Setelah disetujui bersama, sistem resmi digunakan untuk operasi harian.', out: 'Berita acara serah terima' },
  { icon: GraduationCap, title: 'Pelatihan pengguna', time: 'Minggu 6', body: 'Pelatihan per peran: admin, dispatcher, supervisor, mekanik, dan pengemudi — termasuk penggunaan aplikasi mobile, dasbor, laporan, dan penanganan peringatan.', out: 'Materi pelatihan & pengguna tersertifikasi internal' },
  { icon: LifeBuoy, title: 'Pendampingan & dukungan', time: 'Berkelanjutan', body: 'Pendampingan pasca go-live, evaluasi berkala, dan dukungan melalui customercare@opertrace.co.id agar manfaat terus meningkat.', out: 'Laporan evaluasi berkala' },
];

function FleetGuide() {
  return <>
    <PageIntro {...PAGE_IMAGERY.guide} eyebrow="Panduan Alur Armada" title="Dari kebutuhan hingga tim siap bekerja.">Pahami tahapan pembahasan, pemasangan, dan pelatihan sebelum menentukan ruang lingkup penerapan OPERTRACE.</PageIntro>
    <section className="section"><Container>
      <PlaneHeading eyebrow="Persiapan bersama" title="Alur jelas. Ruang lingkup disepakati." lead="Panduan ini adalah gambaran umum. Jadwal, perangkat, hasil kerja, dan dukungan dikonfirmasi sesuai kebutuhan serta kesepakatan Anda." />
      <div className="guide-composition"><DepthFrame src={PAGE_IMAGERY.guide.image} alt={PAGE_IMAGERY.guide.alt} /><OrbitSteps steps={STAGES.map(s => ({title:s.title,body:s.body,note:<>Hasil yang dibahas: {s.out}</>,icon:<s.icon className="size-5" />}))} label="Tahapan penerapan armada" /></div>
    </Container></section>
    <HorizonCta eyebrow="Langkah pertama" title="Mulai dari percakapan, bukan asumsi." primary={{to:'/demo',label:'Mulai dari konsultasi'}} secondary={{to:'/fleet-planner',label:'Tinjau alur dengan AI'}} />
  </>;
}
