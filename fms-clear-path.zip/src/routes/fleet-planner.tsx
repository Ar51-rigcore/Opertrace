import { PAGE_IMAGERY } from '@/lib/page-imagery';
import { createFileRoute } from '@tanstack/react-router';
import { Container, Reveal } from '@/components/site/ui';
import { FleetFlowPlanner } from '@/components/site/FleetFlowPlanner';
import { pageMeta } from '@/lib/page-meta';
import { PageIntro } from '@/components/site/PageIntro';

export const Route = createFileRoute('/fleet-planner')({
  head: () => pageMeta('Perencana Alur Armada AI — OPERTRACE', 'Jelaskan kebutuhan operasional armada Anda dan dapatkan rekomendasi alur kerja SEE → UNDERSTAND → ACT berbasis domain OPERTRACE.'),
  component: FleetPlannerPage,
});

function FleetPlannerPage() {
  return <>
    <PageIntro {...PAGE_IMAGERY.planner} eyebrow="Alur Armada AI" title="Kebutuhan Anda. Alur armada yang jelas.">Untuk pengelola armada yang ingin melihat seperti apa operasi terkendali — sebelum demo pertama.</PageIntro>
    <section className="section"><Container><FleetFlowPlanner /></Container></section>
  </>;
}
