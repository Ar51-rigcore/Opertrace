import { createFileRoute } from '@tanstack/react-router';
import { HorizonHero } from '@/components/site/HorizonHero';
import { MineToPortFlow } from '@/components/site/MineToPortFlow';
import { FleetExperience } from '@/components/site/FleetExperience';
import { AppDownload } from '@/components/site/AppDownload';
import { Container } from '@/components/site/ui';
import { PlaneHeading, PlaneRows, DepthFrame, HorizonCta, PlaneList } from '@/components/site/spatial';
import { PAGE_IMAGERY } from '@/lib/page-imagery';

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "OPERTRACE — Satu Nusantara. Satu Kendali Armada." },
      {
        name: "description",
        content:
          "OPERTRACE oleh PT Cakrakarsa Aditama Nusantara — Physical Operations Intelligence & Execution Platform untuk armada, aset, logistik, dan intelijen bisnis industri.",
      },
      {
        property: "og:title",
        content: "OPERTRACE — Satu Nusantara. Satu Kendali Armada.",
      },
      {
        property: "og:description",
        content:
          "Platform terpadu untuk visibilitas operasional, inteligensi industri, dan eksekusi yang akuntabel.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  return <>
    <HorizonHero />
    <section className="section"><Container>
      <PlaneHeading eyebrow="Kendali operasional" title="Armada terus bergerak. Keputusan tidak perlu tertinggal." lead="Lokasi terpisah adalah kenyataan Indonesia. Informasi yang terputus tidak harus menjadi bagian darinya." />
      <div className="editorial-composition">
        <DepthFrame {...{src: PAGE_IMAGERY.planner.image, alt: PAGE_IMAGERY.planner.alt}} />
        <PlaneRows items={[
          {title:'Satu rujukan bersama', body:'Pembaruan lapangan, catatan perjalanan, dan pekerjaan dibaca dalam konteks yang sama.'},
          {title:'Dari lokasi menuju konteks', body:'Bukan hanya di mana unit berada, tetapi pekerjaan apa yang dijalankan dan kendala apa yang perlu ditinjau.'},
          {title:'Temuan memiliki tindak lanjut', body:'Penanggung jawab, tindakan, dan bukti penyelesaian membantu menjaga kesinambungan operasi.'}
        ]} />
      </div>
    </Container></section>
    <MineToPortFlow />
    <FleetExperience />
    <section className="section"><Container>
      <PlaneHeading eyebrow="Perubahan yang dituju" title="Bukan sekadar laporan. Sebuah pandangan yang terhubung." lead="Ilustrasi skenario penerapan, bukan testimoni atau hasil pelanggan terverifikasi." />
      <PlaneRows columns={2} items={[
        {title:'Tambang hingga pelabuhan', meta:'Dari catatan terpisah menuju rangkaian perjalanan.', body:'Keberangkatan, perjalanan, dan penerimaan menjadi dasar bersama untuk menelusuri jeda dan membahas keterlambatan.'},
        {title:'Perkebunan hingga distribusi', meta:'Kesiapan muatan bertemu penugasan armada.', body:'Tim dapat meninjau perubahan jadwal dan penggunaan kapasitas dari catatan aktivitas yang saling terhubung.'}
      ]} />
    </Container></section>
    <AppDownload />
    <section className="section"><Container>
      <PlaneHeading eyebrow="Nusantara yang terhubung" title="Berbeda medan. Satu arah kendali." lead="Kebutuhan setiap sektor menjadi titik awal pembahasan solusi, bukan dipaksakan ke satu alur yang sama." />
      <PlaneList items={['Pertambangan','Pelabuhan & logistik','Perkebunan','Konstruksi','Energi','Manufaktur']} />
    </Container></section>
    <HorizonCta eyebrow="Langkah berikutnya" title="Jarak tidak perlu menjadi jarak dalam kendali." body="Ceritakan alur yang paling membutuhkan kejelasan. Tinjau kebutuhan bersama tim OPERTRACE sebelum menentukan langkah penerapan." primary={{to:'/demo',label:'Minta demo sesuai operasi Anda'}} secondary={{to:'/contact',label:'Diskusikan kebutuhan'}} />
  </>;
}
