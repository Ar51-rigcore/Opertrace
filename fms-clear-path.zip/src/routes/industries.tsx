import { PlaneHeading, PlaneList, DepthFrame, HorizonCta } from '@/components/site/spatial';
import { INDUSTRY_IMAGERY, PAGE_IMAGERY } from '@/lib/page-imagery';
import { PageIntro } from "@/components/site/PageIntro";
import { createFileRoute } from "@tanstack/react-router";
import { Container, Reveal } from "@/components/site/ui";

export const Route = createFileRoute("/industries")({
  head: () => ({
    meta: [
      { title: "Industri & Solusi Bisnis — OPERTRACE" },
      {
        name: "description",
        content:
          "Solusi terhubung untuk enam sektor: pertambangan, konstruksi, perkebunan, energi, logistik, dan manufaktur. Different Industries. Connected Business Solutions.",
      },
      { property: "og:title", content: "Industri & Solusi Bisnis — OPERTRACE" },
      {
        property: "og:description",
        content: "Different Industries. Connected Business Solutions. Strong Partnerships Build Stronger Industries.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Industries,
});

const SECTORS = [
  {
    n: "01",
    title: "Mining & Mineral Resources",
    headline: "Connecting Mining Operations from Production to Delivery.",
    body: "Mendukung keterhubungan aktivitas pertambangan melalui pengelolaan alat berat, armada, produksi, hauling, stockpile, komoditas, maintenance, dan keselamatan.",
    solutions: ["Heavy Equipment Management", "Fleet & Dispatch", "Mining Production", "Hauling & Weighbridge", "Stockpile & Inventory", "Maintenance", "HSE Management", "Commodity Trading"],
  },
  {
    n: "02",
    title: "Construction & Infrastructure",
    headline: "Better Control Across Every Project and Site.",
    body: "Mendukung perusahaan konstruksi dalam mengelola proyek, peralatan, material, pengadaan, tenaga kerja, dan aktivitas lapangan.",
    solutions: ["Project Management", "Equipment Rental", "Asset Management", "Procurement & Tender", "Material Management", "Fleet Operations", "Maintenance", "Project Cost Intelligence"],
  },
  {
    n: "03",
    title: "Plantation & Agribusiness",
    headline: "Connecting Plantation Assets, Logistics, and Supply Chains.",
    body: "Mendukung pengelolaan aktivitas perkebunan melalui integrasi aset, armada, material, produksi, pengangkutan, dan rantai pasok.",
    solutions: ["Plantation Asset Management", "Fleet Management", "Operational Monitoring", "Material & Inventory", "Logistics Coordination", "Commodity Management", "Maintenance Intelligence", "Business Performance"],
  },
  {
    n: "04",
    title: "Energy & Power",
    headline: "Supporting Asset Reliability and Operational Performance.",
    body: "Mendukung kebutuhan pengelolaan aset, pemeliharaan, proyek, keselamatan, dan informasi operasional sektor energi.",
    solutions: ["Asset Lifecycle Management", "Maintenance & Reliability", "Project Management", "Equipment Monitoring", "Procurement", "Safety & Compliance", "Operational Analytics"],
  },
  {
    n: "05",
    title: "Logistics & Transportation",
    headline: "From Fleet Dispatch to Delivery Accountability.",
    body: "Mendukung perusahaan transportasi dan logistik dalam mengelola armada, perjalanan, pengiriman, kapasitas, biaya, dan bukti penerimaan.",
    solutions: ["Fleet Management", "GPS & Telematics", "Dispatch Management", "Route Monitoring", "Hauling Operations", "Weighbridge", "Proof of Delivery", "Trip Cost Intelligence", "Maritime Logistics"],
  },
  {
    n: "06",
    title: "Manufacturing & Industrial Processing",
    headline: "Connecting Materials, Production, Quality, and Distribution.",
    body: "Mendukung perusahaan manufaktur dan pengolahan industri dalam mengelola aset, material, produksi, kualitas, persediaan, dan distribusi.",
    solutions: ["Asset Management", "Maintenance", "Procurement", "Inventory", "Processing", "Quality Management", "Production Intelligence", "Supply Chain Integration"],
  },
];

const PARTNERS = [
  "Technology Providers", "Industrial Equipment Suppliers", "Fleet & Logistics Companies",
  "Mining Contractors", "Equipment Rental Companies", "Commodity Suppliers & Buyers",
  "Financial & Strategic Partners", "Professional Service Providers", "Research & Innovation Institutions",
];

function Industries() {
  return <>
    <PageIntro {...PAGE_IMAGERY.vision} eyebrow="Industri" title="Berbeda medan. Kebutuhan yang saling terhubung.">Pertambangan, perkebunan, pelabuhan, dan sektor industri lainnya memiliki alur sendiri. OPERTRACE menjadi dasar untuk membahas kebutuhan spesifiknya.</PageIntro>
    <section className="section"><Container className="industry-stories">
      {SECTORS.map((s,i) => <Reveal key={s.title}><article className="industry-story">
        <div className={i % 2 ? 'industry-visual is-reversed' : 'industry-visual'}>{INDUSTRY_IMAGERY[i] && <DepthFrame src={INDUSTRY_IMAGERY[i].image} alt={INDUSTRY_IMAGERY[i].alt} />}</div>
        <div className="industry-copy"><p className="type-label text-brand-text">{s.title}</p><h2 className="text-headline mt-5">{s.headline}</h2><p className="type-body mt-6 text-muted-foreground">{s.body}</p><PlaneList items={s.solutions} label={`Solusi untuk ${s.title}`} /></div>
      </article></Reveal>)}
    </Container></section>
    <section className="section"><Container><PlaneHeading eyebrow="Ekosistem mitra" title="Industri bergerak melalui kerja sama." lead="Peluang kolaborasi terbuka bagi teknologi, peralatan, logistik, dan keahlian profesional." /><PlaneList items={PARTNERS} /></Container></section>
    <HorizonCta eyebrow="Kemitraan industri" title="Mulai dari alur sektor Anda." primary={{to:'/contact',label:'Diskusikan kebutuhan industri'}} secondary={{to:'/platform',label:'Jelajahi platform'}} />
  </>;
}
