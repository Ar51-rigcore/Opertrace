import { PAGE_IMAGERY } from '@/lib/page-imagery';
import { createFileRoute } from '@tanstack/react-router';
import { Container } from '@/components/site/ui';
import { pageMeta } from '@/lib/page-meta';
import { PageIntro } from '@/components/site/PageIntro';

export const Route = createFileRoute('/legal')({
  head: () => pageMeta('Privasi, Ketentuan & Informasi Perusahaan — OPERTRACE', 'Informasi penggunaan situs OPERTRACE, analisis AI, penyimpanan preferensi tampilan, dan identitas perusahaan.'),
  component: Legal,
});
function Legal() {
  return <><PageIntro {...PAGE_IMAGERY.contact} eyebrow="Legal & Informasi Perusahaan" title="Informasi penggunaan situs.">PT Cakrakarsa Aditama Nusantara · OPERTRACE</PageIntro><section className="section"><Container><div className="max-w-3xl">{[
    ['Privasi & analisis AI', 'Teks tantangan dan industri yang Anda kirim diproses melalui Lovable AI Gateway untuk menghasilkan rekomendasi. Situs tidak menyimpan riwayat analisis dalam tabel aplikasi. Jangan mengirim informasi pribadi, kredensial, atau rahasia bisnis. Ketentuan pemrosesan layanan AI tetap berlaku.'],
    ['Ketentuan penggunaan', 'Informasi situs dan rekomendasi AI bersifat informatif, bukan penawaran komersial yang mengikat. Harga, ruang lingkup implementasi, ketersediaan fitur, dan kerja sama harus dikonfirmasi dalam kesepakatan resmi. Rekomendasi AI dapat tidak lengkap atau keliru; validasi dengan tim dan bukti operasional Anda sebelum mengambil tindakan.'],
    ['Cookie & preferensi', 'Situs menyimpan pilihan mode terang atau gelap pada perangkat Anda. Halaman analisis tidak membutuhkan akun atau cookie autentikasi. Infrastruktur hosting dapat menggunakan penyimpanan teknis untuk menjalankan layanan.'],
    ['Informasi perusahaan', 'Nama perusahaan: PT Cakrakarsa Aditama Nusantara. Produk unggulan: OPERTRACE. Kategori: Physical Operations Intelligence & Execution Platform. Alamat: Jl. Mekarwangi Kav. Villa Mutiara, Bogor, Jawa Barat, Indonesia 16161. Telepon: 0881010089399. Email: info@opertrace.co.id. Website: www.opertrace.co.id.'],
  ].map(([title, body]) => <section key={title} className="mb-10 pt-8"><h2 className="text-title">{title}</h2><p className="mt-4 leading-relaxed text-muted-foreground">{body}</p></section>)}<p className="mt-10 text-sm text-muted-foreground">Informasi ini menggambarkan perilaku situs saat ini; bukan pengganti kebijakan perusahaan yang telah ditinjau secara hukum.</p></div></Container></section></>;
}