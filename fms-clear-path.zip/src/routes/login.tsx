import { PAGE_IMAGERY } from '@/lib/page-imagery';
import { createFileRoute } from '@tanstack/react-router';
import { LockKeyhole, ArrowRight } from 'lucide-react';
import { Container, PrimaryButton, GhostButton } from '@/components/site/ui';
import { pageMeta } from '@/lib/page-meta';
import { PageIntro } from '@/components/site/PageIntro';

export const Route = createFileRoute('/login')({
  head: () => pageMeta('Akses Workspace — OPERTRACE', 'Gerbang akses workspace OPERTRACE dan informasi aktivasi akun perusahaan.'),
  component: Login,
});
function Login() {
  return <><PageIntro {...PAGE_IMAGERY.technology} eyebrow="Workspace" title="Akses perusahaan.">OPERTRACE Workspace</PageIntro><section className="section"><Container><div className="max-w-2xl pt-8"><LockKeyhole className="size-9 text-brand-text" /><p className="mt-6 leading-relaxed text-muted-foreground">Masuk dan pendaftaran akun OPERTRACE belum diaktifkan. Halaman ini tidak menerima atau menyimpan kata sandi.</p><p className="mt-4 leading-relaxed text-muted-foreground">Sambil menunggu aktivasi workspace, temukan solusi yang sesuai dengan kebutuhan operasional perusahaan Anda.</p><div className="mt-8 flex flex-col gap-3 sm:flex-row"><PrimaryButton to="/contact">Diskusikan kebutuhan <ArrowRight className="size-4" /></PrimaryButton><GhostButton to="/platform">Jelajahi platform</GhostButton></div></div></Container></section></>;
}