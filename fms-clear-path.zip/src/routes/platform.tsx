import { PlaneHeading, PlaneRows, PlaneList, HorizonCta } from '@/components/site/spatial';
import { createFileRoute } from "@tanstack/react-router";
import { Eye, ShieldCheck, Zap } from "lucide-react";
import { DOMAIN_GROUPS } from "@/lib/opertrace-catalog";
import { AppDownload } from "@/components/site/AppDownload";
import { IndustrialHero } from "@/components/site/IndustrialHero";
import { FleetExperience } from "@/components/site/FleetExperience";
import { Container } from "@/components/site/ui";

export const Route = createFileRoute("/platform")({
  head: () => ({
    meta: [
      { title: "Platform OPERTRACE — 24 Domain Bisnis Terintegrasi" },
      {
        name: "description",
        content:
          "OPERTRACE adalah Physical Operations Intelligence & Execution Platform: armada, aset, maintenance, logistik, komoditas, hingga business intelligence dalam 24 domain terintegrasi.",
      },
      { property: "og:title", content: "Platform OPERTRACE — 24 Domain Bisnis Terintegrasi" },
      {
        property: "og:description",
        content: "One Platform. Total Fleet Control. — Physical Operations Intelligence & Execution Platform.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Platform,
});


const CAPABILITIES = [
  {
    icon: Eye,
    n: "SEE",
    sub: "Total Operational Visibility",
    body: "Status aset, aktivitas armada, penggunaan sumber daya, dan perkembangan pekerjaan dalam satu tampilan yang selalu segar.",
  },
  {
    icon: Zap,
    n: "UNDERSTAND",
    sub: "Industrial Intelligence",
    body: "Analisis produktivitas, biaya, penyimpangan, potensi kehilangan nilai, dan indikator kinerja yang bisa ditindaklanjuti.",
  },
  {
    icon: ShieldCheck,
    n: "ACT",
    sub: "Accountable Execution",
    body: "Workflow, penugasan, persetujuan, tindak lanjut, dan dokumentasi — setiap hasil analisis terhubung ke eksekusi.",
  },
];

const BENEFICIARIES = [
  "Fleet Owners", "Fleet Managers", "Logistics Directors", "Operations Managers",
  "Project Directors", "Procurement Managers", "Mining Companies",
  "Equipment Rental Companies", "Industrial Suppliers", "Commodity Traders",
  "Enterprise Organizations",
];

function Platform() {
  return <>
    <IndustrialHero platform />
    <section className="section"><Container>
      <PlaneHeading eyebrow="Lihat. Pahami. Tindak lanjuti." title="Lokasi adalah awal. Kendali membutuhkan konteks." lead="Pergerakan aset, aktivitas pekerjaan, dan keputusan terhubung dalam satu ekosistem operasional." />
      <PlaneRows columns={2} items={CAPABILITIES.map(c => ({title:c.n,meta:c.sub,body:c.body}))} />
    </Container></section>
    <FleetExperience />
    <section className="section"><Container>
      <PlaneHeading eyebrow="Ekosistem OPERTRACE" title="Fondasi bersama untuk seluruh alur bisnis." lead="Jelajahi domain sesuai kebutuhan operasi Anda, dari identitas dan aset hingga logistik dan inteligensi industri." />
      <div className="catalog-layout">
        {DOMAIN_GROUPS.map(g => <section key={g.group} className="catalog-group">
          <h3 className="type-label text-brand-text">{g.group}</h3>
          <PlaneRows columns={2} items={g.domains.map(d => ({title:d.name,body:d.desc}))} />
        </section>)}
      </div>
    </Container></section>
    <AppDownload />
    <section className="section"><Container>
      <PlaneHeading eyebrow="Tim yang terhubung" title="Satu platform. Banyak sudut pandang." />
      <PlaneList items={BENEFICIARIES} />
    </Container></section>
    <HorizonCta eyebrow="Platform untuk operasi Anda" title="Mulai dari kebutuhan yang paling nyata." body="Tinjau alur, peran pengguna, dan domain yang relevan bersama tim OPERTRACE." primary={{to:'/demo',label:'Minta demo'}} secondary={{to:'/contact',label:'Diskusikan platform'}} />
  </>;
}
