import { PAGE_IMAGERY } from '@/lib/page-imagery';
import { PageIntro } from "@/components/site/PageIntro";
import { createFileRoute } from "@tanstack/react-router";
import { UserRound } from 'lucide-react';
import { Container, FeatureCard, GhostButton, PrimaryButton, Reveal, SectionHeading } from "@/components/site/ui";

export const Route = createFileRoute("/team")({
  head: () => ({
    meta: [
      { title: "Tim Kami — PT Cakrakarsa Aditama Nusantara" },
      {
        name: "description",
        content:
          "Great Companies Are Built by Great People. Kepemimpinan, tim profesional, budaya kerja, dan peluang karier di PT Cakrakarsa Aditama Nusantara.",
      },
      { property: "og:title", content: "Tim Kami — PT Cakrakarsa Aditama Nusantara" },
      { property: "og:description", content: "One Vision. Multiple Expertise. Shared Commitment." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Team,
});

/* Nama direktur sengaja tidak ditampilkan — menunggu data resmi perusahaan. */
const LEADERSHIP = [
  { role: "Direktur Utama", body: "Memimpin arah strategis perusahaan, pengembangan bisnis, kemitraan, investasi, dan pencapaian visi perusahaan." },
  { role: "Direktur Teknologi & Inovasi", body: "Memimpin strategi teknologi, pengembangan platform, arsitektur sistem, dan inovasi produk." },
  { role: "Direktur Operasional & Pengembangan Bisnis", body: "Mengembangkan strategi operasional, solusi industri, kemitraan, dan pelaksanaan program bisnis." },
];

const TEAMS = [
  { title: "Technology & Engineering", body: "Arsitektur teknologi, software engineering, integrasi sistem, dan infrastruktur digital." },
  { title: "Product & Innovation", body: "Menerjemahkan kebutuhan pengguna dan industri menjadi produk serta solusi yang relevan." },
  { title: "Industrial Operations & Solutions", body: "Pemahaman operasional untuk sektor pertambangan, konstruksi, perkebunan, energi, logistik, dan manufaktur." },
  { title: "Data & Artificial Intelligence", body: "Analisis data, intelligence, dan pemanfaatan AI yang bertanggung jawab." },
  { title: "Business Development & Strategic Partnership", body: "Hubungan bisnis, peluang investasi, kerja sama, dan pengembangan pasar." },
  { title: "Finance, Risk & Governance", body: "Pengelolaan keuangan, risiko, administrasi, dan tata kelola perusahaan." },
  { title: "Implementation & Customer Success", body: "Penerapan solusi, pendampingan pelanggan, evaluasi, dan pengembangan layanan." },
];

const CULTURE = [
  "Integrity and Accountability", "Professional Excellence", "Innovation and Creativity",
  "Collaboration and Respect", "Continuous Learning", "Customer Commitment", "Sustainable Thinking",
];

function Team() {
  return (
    <>
      <PageIntro {...PAGE_IMAGERY.team} eyebrow="Tim Kami" title={<>Great Companies Are Built by <span className="text-brand-text">Great People.</span></>}>
        Di balik setiap inovasi terdapat manusia yang memiliki visi, kompetensi, integritas, dan komitmen untuk menciptakan perubahan. Teknologi terbaik lahir dari kolaborasi berbagai keahlian, pengalaman, dan perspektif.
      </PageIntro>

      <section className="section">
        <Container>
          <SectionHeading
            eyebrow="Leadership"
            title="Leading with Vision. Managing with Integrity."
            lead="Kepemimpinan perusahaan diarahkan untuk memastikan setiap strategi, investasi, dan pengembangan bisnis berjalan dengan tata kelola yang baik dan orientasi jangka panjang."
          />
          <div className="mt-14 grid gap-x-12 gap-y-8 md:grid-cols-3">
            {LEADERSHIP.map((l, i) => (
              <Reveal key={l.role} delay={i * 100}>
                <article>
                  <FeatureCard>
                    <div aria-label={`Ruang foto ${l.role}`} className="mb-6 flex aspect-[4/3] w-full items-center justify-center rounded-md bg-muted"><UserRound aria-hidden="true" className="size-16 text-muted-foreground" strokeWidth={1} /></div>
                    <h3 className="text-title text-foreground">{l.role}</h3>
                    <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{l.body}</p>
                  </FeatureCard>
                </article>
              </Reveal>
            ))}
          </div>
        </Container>
      </section>

      <section className="section section-tint">
        <Container>
          <SectionHeading eyebrow="Our Professional Team" title="One Vision. Multiple Expertise. Shared Commitment." />
          <div className="mt-14 grid gap-x-16 gap-y-8 sm:grid-cols-2 lg:grid-cols-3">
            {TEAMS.map((t, i) => (
              <Reveal key={t.title} delay={i * 50}>
                <article>
                  <FeatureCard>
                    <div aria-label={`Ruang foto ${t.title}`} className="mb-5 flex size-20 items-center justify-center rounded-full bg-muted"><UserRound aria-hidden="true" className="size-9 text-muted-foreground" strokeWidth={1} /></div>
                    <h3 className="text-title text-foreground">{t.title}</h3>
                    <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{t.body}</p>
                  </FeatureCard>
                </article>
              </Reveal>
            ))}
          </div>
        </Container>
      </section>

      <section className="section">
        <Container>
          <SectionHeading eyebrow="Our Culture" title="A Culture of Excellence and Continuous Learning." />
          <Reveal className="mt-12">
            <ul className="flex flex-wrap items-center gap-3">
              {CULTURE.map((c) => (
                <li
                  key={c}
                  className="rounded-md bg-card px-5 py-2.5 text-sm text-muted-foreground transition-all duration-300 ease-in-out hover:-translate-y-0.5 hover:text-primary"
                >
                  {c}
                </li>
              ))}
            </ul>
          </Reveal>
          <Reveal className="mt-16 text-center">
            <h2 className="text-headline mx-auto max-w-xl text-balance text-foreground">
              Build Something That Matters.
            </h2>
            <p className="text-lead mx-auto mt-6 max-w-xl">
              Kami terbuka terhadap individu profesional, talenta muda, dan ahli dari berbagai
              bidang yang memiliki semangat inovasi dan keinginan untuk berkontribusi.
            </p>
            <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
              <PrimaryButton to="/contact">Kirim Profil Profesional</PrimaryButton>
              <GhostButton to="/contact">Jelajahi Peluang Karier</GhostButton>
            </div>
          </Reveal>
        </Container>
      </section>
    </>
  );
}
