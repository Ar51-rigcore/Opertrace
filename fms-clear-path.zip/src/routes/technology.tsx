import { PlaneHeading, PlaneRows, PlaneList, DepthFrame, HorizonCta, OrbitSteps } from '@/components/site/spatial';
import { PAGE_IMAGERY } from '@/lib/page-imagery';
import { PageIntro } from "@/components/site/PageIntro";
import { createFileRoute } from "@tanstack/react-router";
import { Container } from "@/components/site/ui";

export const Route = createFileRoute("/technology")({
  head: () => ({
    meta: [
      { title: "Teknologi, Inovasi & Kepercayaan — OPERTRACE" },
      {
        name: "description",
        content:
          "Empat fondasi ilmiah, integritas pengukuran, AI yang bertanggung jawab, serta keamanan dan tata kelola: Innovation Without Integrity Is Not Progress.",
      },
      { property: "og:title", content: "Teknologi, Inovasi & Kepercayaan — OPERTRACE" },
      {
        property: "og:description",
        content: "Every Number Has a Source. Trust Is Built into the Architecture.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Technology,
});

const FOUNDATIONS = [
  { n: "01", title: "Scientific Foundation", body: "Membangun sistem berdasarkan prinsip ilmiah, pendekatan sistem, dan pemahaman terhadap proses fisik serta operasional." },
  { n: "02", title: "Measurement Integrity", body: "Memastikan informasi pengukuran memiliki sumber, metode, satuan, kualitas, dan keterlacakan yang jelas." },
  { n: "03", title: "Human Decision", body: "Merancang teknologi yang membantu manusia memahami informasi, mempertimbangkan alternatif, dan mengambil keputusan secara lebih baik." },
  { n: "04", title: "AI Governance", body: "Mengembangkan penggunaan kecerdasan buatan yang transparan, dapat dievaluasi, dan tetap berada dalam pengawasan manusia." },
];

const SECURITY = [
  "Organization-Based Access", "Role-Based Authorization", "Data Privacy", "Audit Trail",
  "Evidence Management", "Secure Integration", "Tenant Separation",
  "Administrative Governance", "Compliance Management",
];

const PRINCIPLES = [
  { title: "No Evidence → No Claim.", body: "Tidak ada klaim tanpa bukti." },
  { title: "No Authorization → No Action.", body: "Tidak ada tindakan tanpa kewenangan." },
  { title: "No Valid Source → Unverified/Pending.", body: "Informasi tanpa sumber valid tidak boleh diperlakukan sebagai fakta terverifikasi." },
  { title: "Human Accountability.", body: "Keputusan penting tetap berada dalam tanggung jawab manusia yang berwenang." },
];

function Technology() {
  return <>
    <PageIntro {...PAGE_IMAGERY.technology} eyebrow="Teknologi" title="Setiap informasi perlu dasar yang jelas.">Teknologi mendukung kendali ketika sumber dapat ditelusuri, konteks dipahami, dan keputusan tetap berada pada manusia yang berwenang.</PageIntro>
    <section className="section"><Container>
      <PlaneHeading eyebrow="Fondasi teknologi" title="Presisi bukan hanya tampilan angka." lead="Pemahaman proses fisik, kualitas pengukuran, dan tata kelola menjadi arah pengembangan sistem." />
      <div className="editorial-composition"><DepthFrame src={PAGE_IMAGERY.technology.image} alt={PAGE_IMAGERY.technology.alt} /><PlaneRows items={FOUNDATIONS} /></div>
    </Container></section>
    <section className="section"><Container>
      <PlaneHeading eyebrow="Integritas pengukuran" title="Dari pengamatan menuju keputusan." lead="Data yang diamati, diverifikasi, diestimasi, dan diprediksi tidak diperlakukan sebagai hal yang sama." />
      <OrbitSteps axis="x" steps={[
        {title:'Amati & validasi',body:'Tinjau sumber, metode, satuan, dan kualitas informasi.'},
        {title:'Simpan konteks',body:'Pertahankan catatan asal saat informasi dinormalisasi dan diturunkan.'},
        {title:'Putuskan & verifikasi',body:'Tinjau kualitas bukti sebelum tindakan dan konfirmasi hasilnya.'}
      ]} />
    </Container></section>
    <section className="section"><Container>
      <PlaneHeading eyebrow="AI yang bertanggung jawab" title="Rekomendasi membantu. Manusia memutuskan." lead="AI bukan fakta fisik, keputusan hukum, atau pengganti otorisasi. Rekomendasi perlu ditinjau bersama sumber dan konteksnya." />
      <PlaneRows columns={2} items={PRINCIPLES} />
    </Container></section>
    <section className="section"><Container><PlaneHeading eyebrow="Keamanan & tata kelola" title="Kepercayaan memerlukan disiplin." /><PlaneList items={SECURITY} /></Container></section>
    <HorizonCta eyebrow="Diskusi teknologi" title="Inovasi perlu berjalan bersama integritas." primary={{to:'/contact',label:'Diskusikan teknologi'}} secondary={{to:'/platform',label:'Jelajahi platform'}} />
  </>;
}
