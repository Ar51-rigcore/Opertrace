import { PAGE_IMAGERY } from '@/lib/page-imagery';
import { PageIntro } from "@/components/site/PageIntro";
import { createFileRoute } from "@tanstack/react-router";
import { Container, FeatureCard, Reveal, SectionHeading } from "@/components/site/ui";

export const Route = createFileRoute("/vision")({
  head: () => ({
    meta: [
      { title: "Visi, Misi & Core Values — PT Cakrakarsa Aditama Nusantara" },
      {
        name: "description",
        content:
          "Arah dan karakter perusahaan: visi menjadi perusahaan teknologi dan investasi strategis, tujuh misi, dan tujuh core values yang mendefinisikan kami.",
      },
      { property: "og:title", content: "Visi, Misi & Core Values — PT Cakrakarsa Aditama Nusantara" },
      {
        property: "og:description",
        content: "Integrity in Every Decision. Innovation in Every Solution. Responsibility in Every Action.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Vision,
});

const MISSIONS = [
  { n: "01", title: "Technology Innovation", body: "Mengembangkan teknologi dan solusi digital yang inovatif, relevan, dan mampu menjawab kebutuhan bisnis serta tantangan industri." },
  { n: "02", title: "Industrial Transformation", body: "Mendukung transformasi operasional perusahaan melalui integrasi teknologi, data, sistem, dan proses bisnis." },
  { n: "03", title: "Strategic Collaboration", body: "Membangun kemitraan strategis dengan perusahaan, investor, institusi, penyedia teknologi, dan pelaku industri." },
  { n: "04", title: "People Development", body: "Mengembangkan kualitas sumber daya manusia melalui peningkatan kompetensi, kepemimpinan, kreativitas, dan budaya inovasi." },
  { n: "05", title: "Sustainable Industry", body: "Mendorong pemanfaatan teknologi untuk mendukung produktivitas, keselamatan, efisiensi sumber daya, dan praktik industri yang bertanggung jawab." },
  { n: "06", title: "Sustainable Growth", body: "Membangun pertumbuhan perusahaan melalui investasi strategis, tata kelola yang baik, dan penciptaan nilai jangka panjang." },
  { n: "07", title: "National Contribution", body: "Berkontribusi terhadap kemajuan ekonomi dan pengembangan industri Indonesia melalui inovasi, kolaborasi, dan pemanfaatan teknologi." },
];

const VALUES = [
  { title: "Integrity", tag: "Doing What Is Right", body: "Kami menjunjung tinggi kejujuran, transparansi, tanggung jawab, dan konsistensi dalam setiap keputusan dan tindakan — fondasi kepercayaan antara perusahaan, pelanggan, mitra, dan seluruh pemangku kepentingan." },
  { title: "Collaboration", tag: "Growing Together", body: "Kemajuan besar tidak dibangun sendirian. Kami menghargai kolaborasi, keterbukaan, komunikasi, dan kemitraan untuk menghasilkan solusi serta peluang yang lebih baik." },
  { title: "People Development", tag: "Empowering People", body: "Manusia merupakan aset terpenting dalam membangun organisasi. Kami mendorong pengembangan kompetensi, kepemimpinan, kreativitas, dan kesempatan berkembang bagi setiap individu." },
  { title: "Sustainable Industry", tag: "Creating Responsible Progress", body: "Kami mendukung pengembangan industri yang memperhatikan efisiensi sumber daya, keselamatan, tanggung jawab sosial, dan keberlanjutan lingkungan." },
  { title: "Strategic Investment", tag: "Investing in the Future", body: "Kami mengedepankan keputusan investasi yang terukur, memiliki arah strategis, dan berorientasi pada penciptaan nilai jangka panjang." },
  { title: "Sustainable Growth", tag: "Building Lasting Value", body: "Kami mengutamakan pertumbuhan yang sehat, tata kelola yang baik, inovasi, dan hubungan bisnis yang berkelanjutan." },
  { title: "Nusantara", tag: "For a Better Tomorrow", body: "Kami percaya kemajuan teknologi dan industri harus memberikan manfaat yang lebih luas bagi Indonesia — membangun ekosistem bisnis nasional yang semakin maju, produktif, kompetitif, dan terhubung dengan dunia." },
];

function Vision() {
  return (
    <>
      <PageIntro {...PAGE_IMAGERY.vision} eyebrow="Visi & Misi" title={<>Arah yang jelas. <span className="text-brand-text">Nilai yang bertahan.</span></>}>
        Menjadi perusahaan teknologi dan investasi strategis yang unggul dalam membangun solusi inovatif, menghubungkan ekosistem bisnis, serta menciptakan nilai ekonomi dan sosial yang berkelanjutan bagi Indonesia dan dunia.
      </PageIntro>

      <section className="section section-tint">
        <Container>
          <SectionHeading eyebrow="Misi Kami" title="Tujuh komitmen yang memandu setiap langkah kami." />
          <div className="mt-14 grid gap-x-16 gap-y-8 md:grid-cols-2">
            {MISSIONS.map((m, i) => (
              <Reveal key={m.n} delay={i * 60}>
                <article>
                  <FeatureCard>
                    <span className="font-mono text-sm text-primary">{m.n}</span>
                    <h3 className="text-title mt-3 text-foreground">{m.title}</h3>
                    <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{m.body}</p>
                  </FeatureCard>
                </article>
              </Reveal>
            ))}
          </div>
        </Container>
      </section>

      <section className="section">
        <Container>
          <SectionHeading eyebrow="Core Values" title="The Principles That Define Us." />
          <div className="mt-14 grid gap-x-16 gap-y-8 sm:grid-cols-2 lg:grid-cols-3">
            {VALUES.map((v, i) => (
              <Reveal key={v.title} delay={i * 50}>
                <article>
                  <FeatureCard>
                    <span className="font-mono text-xs text-primary">{String(i + 1).padStart(2, "0")}</span>
                    <h3 className="text-title mt-3 text-foreground">{v.title}</h3>
                    <p className="mt-1 text-sm font-medium text-foreground/80">{v.tag}</p>
                    <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{v.body}</p>
                  </FeatureCard>
                </article>
              </Reveal>
            ))}
          </div>
          <Reveal className="mt-16 text-center">
            <p className="text-headline mx-auto max-w-2xl text-balance text-foreground">
              Integrity in Every Decision. Innovation in Every Solution. Responsibility in Every Action.
            </p>
          </Reveal>
        </Container>
      </section>
    </>
  );
}
