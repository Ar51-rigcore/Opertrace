import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

const css = readFileSync('src/styles.css', 'utf8');
function luminance(value: string) {
  const [L, C, h] = value.match(/[\d.]+/g)?.map(Number) ?? [];
  if (L === undefined || C === undefined || h === undefined) throw new Error(`Invalid color token: ${value}`);
  const a = C * Math.cos(h * Math.PI / 180), b = C * Math.sin(h * Math.PI / 180);
  const l = (L + .3963377774*a + .2158037573*b)**3;
  const m = (L - .1055613458*a - .0638541728*b)**3;
  const s = (L - .0894841775*a - 1.291485548*b)**3;
  return .2126*(4.0767416621*l-3.3077115913*m+.2309699292*s) + .7152*(-1.2684380046*l+2.6097574011*m-.3413193965*s) + .0722*(-.0041960863*l-.7034186147*m+1.707614701*s);
}
describe('Critical operational data', () => {
  it.each([':root', '.dark'])('%s achieves the required 7:1 contrast', selector => {
    const block = css.split(`${selector} {`)[1]?.split('}')[0] ?? '';
    const token = (key: string) => {
      const match = block.match(new RegExp(`--${key}:\\s*(oklch\\([^;]+\\));`));
      const value = match?.[1];
      if (!value) throw new Error(`Missing ${key}`);
      return luminance(value);
    };
    const low = Math.min(token('critical-fg'), token('critical-bg'));
    const high = Math.max(token('critical-fg'), token('critical-bg'));
    expect((high + .05) / (low + .05)).toBeGreaterThanOrEqual(7);
  });
});