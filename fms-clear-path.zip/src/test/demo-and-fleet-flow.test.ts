import { describe, expect, it } from 'vitest';
import { demoRequestSchema } from '@/lib/demo-request-schema';
import { fleetNeedsSchema, hasOnlyKnownDomains } from '@/lib/fleet-flow-schema';
import { DOMAIN_GROUPS } from '@/lib/opertrace-catalog';

const needs = 'Antrean loading panjang dan downtime unit baru diketahui setelah laporan harian.';

describe('demo request form', () => {
  it('requires name, email and fleet needs', () => {
    expect(demoRequestSchema.safeParse({ name: 'Arief', email: 'arief@perusahaan.co.id', fleetNeeds: needs }).success).toBe(true);
    expect(demoRequestSchema.safeParse({ name: '', email: 'arief@perusahaan.co.id', fleetNeeds: needs }).success).toBe(false);
    expect(demoRequestSchema.safeParse({ name: 'Arief', email: 'bukan-email', fleetNeeds: needs }).success).toBe(false);
    expect(demoRequestSchema.safeParse({ name: 'Arief', email: 'arief@perusahaan.co.id', fleetNeeds: 'pendek' }).success).toBe(false);
  });
});

describe('fleet flow planner', () => {
  it('accepts a fleet manager description without fleet size', () => {
    expect(fleetNeedsSchema.safeParse({ industry: 'Pertambangan', needs }).success).toBe(true);
  });
  it('rejects flows that name a domain outside the catalog', () => {
    const known = DOMAIN_GROUPS.flatMap(g => g.domains).map(d => d.name);
    const base = { summary: 's', questions: [], caution: 'c' };
    expect(hasOnlyKnownDomains({ ...base, stages: [{ phase: 'SEE', title: 't', action: 'a', domain: 'Fleet Live & Dispatch', metric: 'm' }] }, known)).toBe(true);
    expect(hasOnlyKnownDomains({ ...base, stages: [{ phase: 'ACT', title: 't', action: 'a', domain: 'Invented Module', metric: 'm' }] }, known)).toBe(false);
  });
});
