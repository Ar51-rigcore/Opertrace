import { describe, expect, it } from 'vitest';
import { collectFleetFlowText } from '@/lib/fleet-flow-stream';

describe('fleet planner stream completion', () => {
  it('returns the finished result without waiting for the connection to close', async () => {
    let closed = false;
    async function* events() {
      try {
        yield { type: 'response.output_text.delta', delta: '{"summary":' };
        yield { type: 'response.output_text.delta', delta: '"Armada"}' };
        yield { type: 'response.completed' };
        throw new Error('Must not read beyond the terminal event');
      } finally { closed = true; }
    }
    expect(await collectFleetFlowText(events())).toEqual({ text: '{"summary":"Armada"}', completed: true });
    expect(closed).toBe(true);
  });
  it('does not treat incomplete output as a successful recommendation', async () => {
    async function* events() {
      yield { type: 'response.output_text.delta', delta: '{' };
      yield { type: 'response.incomplete' };
      throw new Error('Must stop at incomplete');
    }
    expect(await collectFleetFlowText(events())).toEqual({ text: '{', completed: false });
  });
  it('propagates transport errors without replaying inference', async () => {
    async function* events() { yield { type: 'response.created' }; throw new Error('transport'); }
    await expect(collectFleetFlowText(events())).rejects.toThrow('transport');
  });
});