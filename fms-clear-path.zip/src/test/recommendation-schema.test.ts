import { describe, expect, it } from 'vitest';
import { DOMAIN_GROUPS } from '@/lib/opertrace-catalog';
import { challengeSchema } from '@/lib/recommendation-schema';

describe('OPERTRACE advisor grounding', () => {
  it('uses the same 24 domains as the platform', () => {
    expect(DOMAIN_GROUPS.flatMap(g => g.domains)).toHaveLength(24);
  });
  it('accepts an operational challenge', () => {
    expect(challengeSchema.safeParse({ industry: 'Pertambangan', challenge: 'Downtime alat berat berulang dan persediaan suku cadang tidak akurat.' }).success).toBe(true);
  });
});