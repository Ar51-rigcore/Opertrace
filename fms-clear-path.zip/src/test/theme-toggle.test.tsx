import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { ThemeToggle } from '@/components/site/ThemeToggle';

afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  localStorage.clear();
  document.documentElement.classList.remove('dark');
});

describe('Theme switching', () => {
  it.each(['light', 'dark'])('restores the saved %s preference and persists a change', theme => {
    localStorage.setItem('opertrace-theme', theme);
    render(<ThemeToggle />);
    expect(document.documentElement.classList.contains('dark')).toBe(theme === 'dark');
    fireEvent.click(screen.getByRole('button'));
    expect(document.documentElement.classList.contains('dark')).toBe(theme !== 'dark');
    expect(localStorage.getItem('opertrace-theme')).toBe(theme === 'dark' ? 'light' : 'dark');
  });

  it('can switch modes when reading and writing storage is blocked', () => {
    vi.spyOn(Storage.prototype, 'getItem').mockImplementation(() => { throw new DOMException('Blocked', 'SecurityError'); });
    vi.spyOn(Storage.prototype, 'setItem').mockImplementation(() => { throw new DOMException('Blocked', 'SecurityError'); });
    render(<ThemeToggle />);
    expect(document.documentElement.classList.contains('dark')).toBe(false);
    fireEvent.click(screen.getByRole('button'));
    expect(document.documentElement.classList.contains('dark')).toBe(true);
    fireEvent.click(screen.getByRole('button'));
    expect(document.documentElement.classList.contains('dark')).toBe(false);
  });
});